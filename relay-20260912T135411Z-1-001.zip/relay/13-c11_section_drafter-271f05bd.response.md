{
  "section_id": "decision",
  "h2": "Which to use, and when",
  "body_md": "A rule you can apply tonight, without deciding which tool you prefer.\n\n**Ask what the image is being judged on.** If a human decides whether it is good, use a design tool. If a portal decides whether it is acceptable, use a spec tool.\n\nReach for **Canva** when you are making a festival offer post, an Instagram carousel, a WhatsApp status, a price list, a shop banner, or anything where you want your name visible. Composition is the job and freedom is the point.\n\nReach for a **listing tool** when a catalog primary image needs an exact size and file weight, when the same photo has to serve Meesho and Flipkart and Amazon at once, when a drop of forty needs the same treatment applied identically, or when a catalog has come back rejected and you are not sure why.\n\nMost sellers need both, on different evenings. The mistake is not choosing wrongly between them — it is not noticing there were two jobs, and bringing design instincts to a page that rejects them (fact:fixes-the-things-that-actually-get-listi).\n\nIf your listings go live without trouble, nothing here needs to change. If they keep bouncing, start with the primary image and take everything off it that is not the product.",
  "entities_covered": ["Canva", "design tool", "listing tool", "decision"],
  "verify_flags": []
}
