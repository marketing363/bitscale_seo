"""Web-fetch / RAG evidence tool — turns [VERIFY] flags into cited sources.

This is the retrieval "hand" the pipeline was missing. Given a claim or a
`[VERIFY: …]` flag, it:
  1. turns it into a search query (SERP via tools.serp),
  2. fetches the top result pages (tools.fetch.fetch_rendered),
  3. extracts the most relevant passage(s) — sentences that overlap the query
     and/or carry a number,
  4. records them in the brand brain (evidence table) with provenance,
  5. returns a resolution: {flag, status: resolved|unresolved, source_url, passage}.

Honest degradation: if search/fetch is unavailable (no network, blocked domain),
the flag stays `unresolved` and is surfaced as a human checkpoint — never
fabricated. Nothing here invents a source.
"""
from __future__ import annotations

import re
from pathlib import Path
from urllib.parse import urlparse

import yaml


def _cfg() -> dict:
    return yaml.safe_load((Path(__file__).resolve().parents[1] / "config.yaml").read_text())


# Generic English stopwords only. The brand name used to be hardcoded in here
# ("siftly"), which quietly did the wrong thing for every other brand: the term was
# dropped from evidence queries for one brand and kept for all the rest. Brand terms
# now come from the loaded profile via _brand_stopwords().
_STOP = set("the a an of to in on for and or is are be as with by your you we our it that this "
            "what which how why does do can".split())


def _brand_stopwords(brand: dict | None = None) -> set[str]:
    """The brand's own name, so evidence queries do not retrieve on it."""
    if not brand:
        return set()
    words: set[str] = set()
    for key in ("name", "domain"):
        val = str(brand.get(key) or "")
        for token in re.findall(r"[a-z]+", val.lower()):
            if len(token) > 2:
                words.add(token)
    return words


def _query_from_flag(flag: str) -> str:
    """'[VERIFY: source/date for Google AI Mode launch]' -> 'Google AI Mode launch date'."""
    t = re.sub(r"\[VERIFY:?\s*", "", flag).rstrip("]").strip()
    t = re.sub(r"^(source|date|url|internal url|stat|number)\s*(/?\s*(source|date|url))?\s*for\s*", "", t, flags=re.I)
    return t.strip() or flag.strip("[]")


def _relevant_passages(text: str, query: str, k: int = 2, brand: dict | None = None) -> list[str]:
    stop = _STOP | _brand_stopwords(brand)
    terms = {w for w in re.findall(r"[a-z]+", query.lower()) if w not in stop and len(w) > 2}
    if not terms:
        return []
    sents = re.split(r"(?<=[.!?])\s+", text)
    scored = []
    for s in sents:
        s = s.strip()
        if not (20 <= len(s) <= 320):
            continue
        low = s.lower()
        hit = sum(1 for t in terms if t in low)
        if hit == 0:
            continue
        bonus = 1 if re.search(r"\d", s) else 0
        scored.append((hit + bonus, s))
    scored.sort(key=lambda x: -x[0])
    return [s for _, s in scored[:k]]


def gather_evidence(query: str, max_sources: int = 3, allow_domains: list[str] | None = None,
                    timeout_s: int = 20) -> list[dict]:
    """Search + fetch + extract. Returns [{source_url, source_domain, passage}]."""
    out: list[dict] = []
    try:
        from tools.serp import serp_search
        sr = serp_search(query) or {}
        results = sr.get("results") or sr.get("organic") or []
    except Exception:
        results = []
    urls = []
    for r in results:
        u = r.get("url") or r.get("link") if isinstance(r, dict) else r
        if not u:
            continue
        dom = urlparse(u).netloc.lower()
        if allow_domains and not any(d in dom for d in allow_domains):
            continue
        urls.append(u)
        if len(urls) >= max_sources:
            break
    from tools.fetch import fetch_rendered
    for u in urls:
        try:
            page = fetch_rendered(u)
        except Exception:
            continue
        for p in _relevant_passages(page.get("text", ""), query):
            out.append({"source_url": u, "source_domain": urlparse(u).netloc, "passage": p})
        if out:
            break  # one good source is enough per flag; widen only if none found
    return out


def resolve_flags(domain: str, flags: list[str], brain=None, cfg: dict | None = None) -> list[dict]:
    """For each [VERIFY] flag, try to find a real citation. Records found
    evidence in the brain. Returns resolution records."""
    cfg = cfg or _cfg()
    ecfg = (cfg.get("tools", {}).get("evidence") or {})
    if not ecfg.get("enabled", True):
        return [{"flag": f, "status": "disabled"} for f in flags]
    if brain is None:
        from tools.brain import Brain
        brain = Brain()
    maxs = int(ecfg.get("max_sources_per_flag", 3))
    allow = ecfg.get("allow_domains") or None
    timeout = int(ecfg.get("fetch_timeout_s", 20))

    resolutions = []
    for flag in flags:
        q = _query_from_flag(flag)
        # internal-URL asks can't be answered by the open web — route to user
        if re.search(r"internal url|/[a-z\-]+/[a-z\-]+", flag, re.I) and "http" not in flag:
            resolutions.append({"flag": flag, "status": "needs_user_input",
                                "note": "internal URL — supply from site structure"})
            continue
        ev = gather_evidence(q, max_sources=maxs, allow_domains=allow, timeout_s=timeout)
        if ev:
            top = ev[0]
            brain.add_evidence(domain, q, top["source_url"], top["source_domain"], top["passage"])
            resolutions.append({"flag": flag, "status": "resolved",
                                "source_url": top["source_url"], "source_domain": top["source_domain"],
                                "passage": top["passage"]})
        else:
            resolutions.append({"flag": flag, "status": "unresolved",
                                "note": "no source found via web search/fetch"})
    return resolutions
