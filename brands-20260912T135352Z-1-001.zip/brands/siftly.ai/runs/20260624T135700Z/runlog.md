# Run log

- total cost: **$0.5445** (budget $3.0)
- total node time: **734.5s** (budget 15 min)
- route-back counts: {}

## c0_intake_router
- output keys: human_checkpoints
- duration: 0.0 ms
- guardrail: {'check': 'intake_required_inputs', 'status': 'pass'}

## c1_source_reconciler
- output keys: conflicts, facts_ledger
- duration: 9287.1 ms · cost: $0.003201
- model call: claude-code:claude-sonnet-4-6 — 2 in / 213 out ($0.003201)
- guardrail: {'check': 'seed_ledger', 'facts': 28, 'conflicts': 0}

## c2_cannibalization
- output keys: delegate_list, intent_contract, page_intent
- duration: 1.0 ms
- guardrail: {'check': 'cannibalization', 'status': 'not-checked', 'note': 'no sitemap configured for this account'}
- guardrail: {'check': 'intent_guard', 'mode': 'single-page', 'governed': False, 'page_intent': 'ai prompt analytics', 'primary_intent_type': 'commercial', 'delegate': [], 'head_queries': 0, 'host_vs_link': []}

## c3_kw_intent_mapper
- output keys: intent, keyword_cluster, serp_analysis
- duration: 0.3 ms
- guardrail: {'check': 'keyword_research', 'source': 'stub', 'terms': 1, 'real_volumes': False}

## c4_serp_landscape
- output keys: serp_analysis, serp_feature_targets
- duration: 0.1 ms

## c5_competitor_content
- output keys: competitors, gap_entity_matrix
- duration: 0.1 ms
- guardrail: {'check': 'competitor_gaps', 'confidence': 'stub', 'note': 'stub SERP — gap derived from result titles only; competitor pages not fetched'}

## c6_brand_loader
- output keys: brand_voice, human_checkpoints
- duration: 34111.7 ms · cost: $0.020374
- model call: claude-code:claude-haiku-4-5-20251001 — 9 in / 4073 out ($0.020374)
- guardrail: {'check': 'testimonial_permissions', 'usable': 3, 'excluded': 0}

## c7_strategist
- output keys: strategy, unique_insight
- duration: 86368.1 ms · cost: $0.081756
- model call: claude-code:claude-sonnet-4-6 — 2 in / 5450 out ($0.081756)
- guardrail: {'check': 'grounding_check', 'violations': ['Siftly tracks brand and competitor visibility across 9 AI engines: ChatGPT, Gemini, Claude, Perplexity, Google AI Overviews, Google AI Mode,', 'Domu went from no AI-search visibility to ranking #9 within a month, with gains across Google AI Overviews, Perplexity, and ChatGPT. (fact:p', 'KIWABI grew revenue from ChatGPT by 3.5x month over month. (fact:proof-kiwabi-grew-revenue-from-chatgpt, fact:testimonial-kiwabi)', 'BROMO now sees leads come through Google AI Overviews and ChatGPT, making AI search a channel they can take to market. (fact:proof-bromo-now']}

## c8_brief_compiler
- output keys: brief
- duration: 77148.9 ms · cost: $0.046604
- model call: claude-code:claude-haiku-4-5-20251001 — 9 in / 9319 out ($0.046604)
- guardrail: {'check': 'brief_compiled', 'page_type': 'feature', 'structure_blocks': 8, 'required_blocks': ['answer_first', 'problem', 'how_it_works', 'capabilities', 'differentiators', 'proof', 'faq', 'cta']}

## c9_outline
- output keys: outline
- duration: 37418.8 ms · cost: $0.028234
- model call: claude-code:claude-haiku-4-5-20251001 — 9 in / 5645 out ($0.028234)
- guardrail: {'check': 'entity_coverage', 'unassigned': [], 'sections': 8}
- guardrail: {'check': 'intent_boundary', 'trespasses': []}

## c10_hook
- output keys: lead
- duration: 39221.5 ms · cost: $0.024054
- model call: claude-code:claude-haiku-4-5-20251001 — 9 in / 4809 out ($0.024054)
- guardrail: {'check': 'answer_first', 'words': 60, 'flag_dont_fill': []}

## c11_section_drafter
- output keys: sections
- duration: 389769.0 ms · cost: $0.293832
- model call: claude-code:claude-haiku-4-5-20251001 — 9 in / 5843 out ($0.029224)
- model call: claude-code:claude-haiku-4-5-20251001 — 9 in / 4141 out ($0.020714)
- model call: claude-code:claude-haiku-4-5-20251001 — 9 in / 6758 out ($0.033799)
- model call: claude-code:claude-haiku-4-5-20251001 — 9 in / 5775 out ($0.028884)
- model call: claude-code:claude-haiku-4-5-20251001 — 9 in / 9032 out ($0.045169)
- model call: claude-code:claude-haiku-4-5-20251001 — 9 in / 14858 out ($0.074299)
- model call: claude-code:claude-haiku-4-5-20251001 — 9 in / 8499 out ($0.042504)
- model call: claude-code:claude-haiku-4-5-20251001 — 9 in / 3846 out ($0.019239)
- guardrail: {'check': 'flag_dont_fill', 'sections': 8, 'violations': []}

## c12_faq
- output keys: faq
- duration: 61150.1 ms · cost: $0.046454
- model call: claude-code:claude-haiku-4-5-20251001 — 9 in / 9289 out ($0.046454)
- guardrail: {'check': 'faq', 'count': 6}

## c13_evidence
- output keys: human_checkpoints, verify_list
- duration: 0.0 ms
- guardrail: {'check': 'evidence', 'unresolved_flags': 0}

## c14_eeat
- output keys: human_checkpoints
- duration: 0.0 ms
- guardrail: {'check': 'eeat_from_brand_assets_only', 'author': False, 'testimonials_used': 3, 'testimonials_excluded': 0}

## c15_media
- output keys: human_checkpoints, media_manifest, svg_assets
- duration: 0.1 ms
- guardrail: {'check': 'media', 'items': 1, 'base64': 0, 'ok': True}

## c16_editorial
- output keys: draft, human_checkpoints
- duration: 14.9 ms
- guardrail: {'check': 'no_new_facts', 'new_numbers': [], 'ok': True}
- guardrail: {'check': 'cut_unverified', 'count': 0}

## c17_a11y_perf
- output keys: (none)
- duration: 0.3 ms
- guardrail: {'check': 'a11y_perf', 'violations': [], 'ok': True}

## c18_schema
- output keys: schema_jsonld
- duration: 0.1 ms
- guardrail: {'check': 'schema', 'page_type': 'feature', 'types': ['WebPage', 'SoftwareApplication', 'FAQPage', 'Review', 'Review', 'Review'], 'approved_reviews': 3}

## c19_critic
- output keys: critic_report
- duration: 25.9 ms
- guardrail: {'check': 'critic', 'verdict': 'pass', 'failures': 5}

## c20_render_critic
- output keys: render_report
- duration: 4.7 ms
- guardrail: {'check': 'render_critic', 'verdict': 'pass', 'failures': 0}

## c21_comparison_judge
- output keys: comparison_report
- duration: 0.0 ms

## c22_packager
- output keys: package_out
- duration: 0.0 ms
- guardrail: {'check': 'packaged', 'ok': True}

