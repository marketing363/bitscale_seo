{
  "outline": [
    {
      "id": "answer",
      "h2": "The short answer",
      "word_budget": 70,
      "intent": "Answer-first verdict, quotable standing alone. Two different jobs: a design tool composes something new, a listing image takes an existing photograph to an exact specification with nothing added. Name who should stay on Canva in the same breath.",
      "entities_assigned": [
        "Canva",
        "primary image",
        "marketplace listing",
        "specification"
      ],
      "facts_needed": [
        "proof-marketplace-hero-images-are-kept"
      ],
      "keep_items_assigned": []
    },
    {
      "id": "canva_wins",
      "h2": "What Canva is genuinely better at",
      "word_budget": 200,
      "intent": "Concede first and concretely - social posts, festive creatives, banners, price lists, anything composed rather than conformed. A reader who cannot find her own use case honestly described here stops trusting the page. Category-level statements only; no Canva feature, limit, plan or price asserted.",
      "entities_assigned": [
        "Canva",
        "design tool",
        "social post",
        "banner",
        "Instagram"
      ],
      "facts_needed": [],
      "keep_items_assigned": []
    },
    {
      "id": "two_jobs",
      "h2": "Designing something new is not the same job as meeting a spec",
      "word_budget": 220,
      "intent": "The page's owned idea. A design tool trains you to add - shop name, frame, collage of the range. A primary catalog image is judged on having none of it, so the seller most fluent in a design tool often gets rejected most.",
      "entities_assigned": [
        "primary image",
        "catalog",
        "QC",
        "watermark",
        "collage",
        "Meesho"
      ],
      "facts_needed": [
        "proof-marketplace-hero-images-are-kept",
        "fixes-the-things-that-actually-get-listi"
      ],
      "keep_items_assigned": []
    },
    {
      "id": "portal_rules",
      "h2": "The rules a design tool has no reason to know",
      "word_budget": 260,
      "intent": "Pixel dimensions and file size set independently, aspect ratio that fills the box rather than letterboxing, and a primary image carrying nothing but the product. Why each fails a catalog. Link the full spec rather than reproducing numbers.",
      "entities_assigned": [
        "pixel dimensions",
        "file size",
        "KB limit",
        "aspect ratio",
        "Meesho",
        "Flipkart",
        "Amazon",
        "Myntra"
      ],
      "facts_needed": [
        "feat-free-kb-and-pixel-resizers",
        "feat-marketplace-image-tools",
        "exact-meesho-myntra-flipkart-and-amazon-"
      ],
      "keep_items_assigned": []
    },
    {
      "id": "whole_drop",
      "h2": "One image, or forty",
      "word_budget": 190,
      "intent": "Scale changes which tool is right. Designing forty listing images one at a time is an evening; a spec pipeline is one pass. Where the WhatsApp catalogue belongs. Earns the commercial bridge without becoming a pitch.",
      "entities_assigned": [
        "drop",
        "SKU",
        "bulk",
        "WhatsApp catalogue",
        "PDF"
      ],
      "facts_needed": [
        "feat-bulk-photo-pack",
        "exact-meesho-myntra-flipkart-and-amazon-",
        "feat-whatsapp-catalogue",
        "built-for-a-phone-because-that-is-what-t"
      ],
      "keep_items_assigned": []
    },
    {
      "id": "objections",
      "h2": "Free, private, and not a subscription",
      "word_budget": 180,
      "intent": "The three objections a seller actually has, answered in her words: is it really free, do my photos get uploaded, am I signing up for a monthly charge. Link pricing so the pack terms are checkable.",
      "entities_assigned": [
        "free",
        "signup",
        "watermark",
        "browser",
        "subscription",
        "rupees"
      ],
      "facts_needed": [
        "free-on-single-photos-no-signup-no-water",
        "proof-single-photo-tools-are-genuinely",
        "proof-processing-happens-in-the-browse",
        "photos-never-leave-the-device-everything",
        "proof-one-off-99-pack-rather-than-a-su",
        "one-photo-counts-once-however-many-steps"
      ],
      "keep_items_assigned": []
    },
    {
      "id": "decision",
      "h2": "Which to use, and when",
      "word_budget": 160,
      "intent": "A decision rule applicable the same evening. Two short lists - reach for a design tool when X, reach for a spec tool when Y - with Canva the right answer in roughly half the cases. Ends on the reader's judgement, not the product.",
      "entities_assigned": [
        "Canva",
        "design tool",
        "listing tool",
        "decision"
      ],
      "facts_needed": [
        "fixes-the-things-that-actually-get-listi"
      ],
      "keep_items_assigned": []
    }
  ],
  "coverage_map": {
    "Canva": "canva_wins",
    "design tool": "canva_wins",
    "social post": "canva_wins",
    "banner": "canva_wins",
    "Instagram": "canva_wins",
    "primary image": "two_jobs",
    "catalog": "two_jobs",
    "QC": "two_jobs",
    "collage": "two_jobs",
    "watermark": "two_jobs",
    "pixel dimensions": "portal_rules",
    "file size": "portal_rules",
    "KB limit": "portal_rules",
    "aspect ratio": "portal_rules",
    "Meesho": "portal_rules",
    "Flipkart": "portal_rules",
    "Amazon": "portal_rules",
    "Myntra": "portal_rules",
    "drop": "whole_drop",
    "SKU": "whole_drop",
    "bulk": "whole_drop",
    "WhatsApp catalogue": "whole_drop",
    "PDF": "whole_drop",
    "free": "objections",
    "signup": "objections",
    "browser": "objections",
    "subscription": "objections",
    "rupees": "objections",
    "listing tool": "decision",
    "decision": "decision",
    "specification": "answer",
    "marketplace listing": "answer",
    "catalog rejected": "two_jobs",
    "listing image size": "portal_rules",
    "e-commerce": "portal_rules"
  },
  "unassigned": []
}