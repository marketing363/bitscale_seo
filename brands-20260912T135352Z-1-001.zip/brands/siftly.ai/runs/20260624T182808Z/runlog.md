# Run log

- total cost: **$0.3898** (budget $3.0)
- total node time: **133.2s** (budget 15 min)
- route-back counts: {}

## c0_intake_router
- output keys: human_checkpoints
- duration: 0.0 ms
- guardrail: {'check': 'intake_required_inputs', 'status': 'pass'}

## c1_source_reconciler
- output keys: conflicts, facts_ledger
- duration: 3254.5 ms · cost: $0.005148
- model call: azure:gpt-5.5 — 1641 in / 15 out ($0.005148)
- guardrail: {'check': 'seed_ledger', 'facts': 28, 'conflicts': 0}

## c2_cannibalization
- output keys: delegate_list, intent_contract, page_intent
- duration: 15.3 ms
- guardrail: {'check': 'cannibalization', 'status': 'not-checked', 'note': 'no sitemap configured for this account'}
- guardrail: {'check': 'intent_guard', 'mode': 'single-page', 'governed': True, 'page_intent': 'ai prompt analytics', 'primary_intent_type': 'commercial', 'delegate': [], 'head_queries': 1000, 'host_vs_link': []}

## c3_kw_intent_mapper
- output keys: intent, keyword_cluster, serp_analysis
- duration: 0.7 ms
- guardrail: {'check': 'keyword_research', 'source': 'stub', 'terms': 1, 'real_volumes': False}

## c4_serp_landscape
- output keys: serp_analysis, serp_feature_targets
- duration: 0.0 ms

## c5_competitor_content
- output keys: competitors, gap_entity_matrix
- duration: 0.1 ms
- guardrail: {'check': 'competitor_gaps', 'confidence': 'stub', 'note': 'stub SERP — gap derived from result titles only; competitor pages not fetched'}

## c6_brand_loader
- output keys: brand_voice, human_checkpoints
- duration: 17600.7 ms · cost: $0.013385
- model call: azure:gpt-5.5 — 6275 in / 1422 out ($0.013385)
- guardrail: {'check': 'testimonial_permissions', 'usable': 3, 'excluded': 0}

## c7_strategist
- output keys: strategy, unique_insight
- duration: 26831.8 ms · cost: $0.217962
- model call: azure:gpt-5.5 — 62834 in / 1964 out ($0.217962)
- guardrail: {'check': 'grounding_check', 'violations': []}

## c8_brief_compiler
- output keys: brief
- duration: 25324.5 ms · cost: $0.012785
- model call: azure:gpt-5.5 — 2520 in / 2053 out ($0.012785)
- guardrail: {'check': 'brief_compiled', 'page_type': 'feature', 'structure_blocks': 8, 'required_blocks': ['answer_first', 'problem', 'how_it_works', 'capabilities', 'differentiators', 'proof', 'faq', 'cta']}

## c9_outline
- output keys: outline
- duration: 28956.9 ms · cost: $0.019532
- model call: azure:gpt-5.5 — 3922 in / 3122 out ($0.019532)
- guardrail: {'check': 'entity_coverage', 'unassigned': {'entities': [], 'keep_items': [], 'required_blocks': []}, 'sections': 8}
- guardrail: {'check': 'intent_boundary', 'trespasses': []}

## c10_hook
- output keys: lead
- duration: 3952.8 ms · cost: $0.002671
- model call: azure:gpt-5.5 — 2021 in / 130 out ($0.002671)
- guardrail: {'check': 'answer_first', 'words': 55, 'flag_dont_fill': []}

## c11_section_drafter
- output keys: sections
- duration: 14617.2 ms · cost: $0.112536
- model call: azure:gpt-5.5 — 11375 in / 217 out ($0.01246)
- model call: azure:gpt-5.5 — 11496 in / 340 out ($0.013196)
- model call: azure:gpt-5.5 — 11567 in / 484 out ($0.013987)
- model call: azure:gpt-5.5 — 11642 in / 568 out ($0.014482)
- model call: azure:gpt-5.5 — 11467 in / 452 out ($0.013727)
- model call: azure:gpt-5.5 — 11578 in / 602 out ($0.014588)
- model call: azure:gpt-5.5 — 11504 in / 504 out ($0.014024)
- model call: azure:gpt-5.5 — 11772 in / 860 out ($0.016072)
- guardrail: {'check': 'flag_dont_fill', 'sections': 8, 'violations': []}

## c12_faq
- output keys: faq
- duration: 12402.8 ms · cost: $0.005745
- model call: azure:gpt-5.5 — 1615 in / 826 out ($0.005745)
- guardrail: {'check': 'faq', 'count': 8}

## c13_evidence
- output keys: human_checkpoints, verify_list
- duration: 0.1 ms
- guardrail: {'check': 'evidence', 'unresolved_flags': 8}

## c14_eeat
- output keys: human_checkpoints
- duration: 0.1 ms
- guardrail: {'check': 'eeat_from_brand_assets_only', 'author': True, 'testimonials_used': 3, 'testimonials_excluded': 0}

## c15_media
- output keys: human_checkpoints, media_manifest, svg_assets
- duration: 5.5 ms
- guardrail: {'check': 'media', 'items': 1, 'base64': 0, 'ok': True}

## c16_editorial
- output keys: draft, human_checkpoints
- duration: 12.9 ms
- guardrail: {'check': 'no_new_facts', 'new_numbers': [], 'ok': True}
- guardrail: {'check': 'cut_unverified', 'count': 8}

## c17_a11y_perf
- output keys: (none)
- duration: 0.2 ms
- guardrail: {'check': 'a11y_perf', 'violations': [], 'ok': True}

## c18_schema
- output keys: schema_jsonld
- duration: 0.1 ms
- guardrail: {'check': 'schema', 'page_type': 'feature', 'types': ['WebPage', 'SoftwareApplication', 'FAQPage', 'Person', 'Review', 'Review', 'Review'], 'approved_reviews': 3}

## c19_critic
- output keys: critic_report
- duration: 235.0 ms
- guardrail: {'check': 'critic', 'verdict': 'pass', 'failures': 3}

## c20_render_critic
- output keys: render_report
- duration: 2.1 ms
- guardrail: {'check': 'render_critic', 'verdict': 'pass', 'failures': 0}

## c21_comparison_judge
- output keys: comparison_report
- duration: 0.0 ms

## c22_packager
- output keys: package_out
- duration: 0.1 ms
- guardrail: {'check': 'packaged', 'byline': True, 'last_updated': '24 June 2026'}

