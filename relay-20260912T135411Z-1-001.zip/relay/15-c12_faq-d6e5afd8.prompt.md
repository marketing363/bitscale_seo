ROLE: FAQ writer.
INPUT: paa_questions=[], outline_summary=["The short answer", "What Canva is genuinely better at", "Designing something new is not the same job as meeting a spec", "The rules a design tool has no reason to know", "One image, or forty", "Free, private, and not a subscription", "Which to use, and when", "Frequently asked questions"], primary_keyword="canva alternative for product photos"
TASK: Write >=5 FAQs. Source questions from the PAA list first; fill from the outline's natural follow-ups. Each answer: 40-70 words, answer-first, no NEW statistics (numbers only with (fact:id)). Skip any question whose answer would duplicate a body section verbatim — note it in dropped_as_duplicate.
OUTPUT: JSON with keys faq (list: q, a), dropped_as_duplicate (list).

RULES (non-negotiable):
- Assert only facts present in the FACTS LEDGER below or directly quoted from CANONICAL SOURCES.
- A missing fact must be written as [VERIFY: what is missing]. Never invent a number, source, feature, credential, quote, or URL.
- When citing a ledger fact inline, append its id like (fact:engines-count).
- Output ONLY the JSON object matching the schema given. No prose around it.
FACTS LEDGER:
| id | claim | value | status | source |
|---|---|---|---|---|
| exact-meesho-myntra-flipkart-and-amazon- | Value proposition | Exact Meesho, Myntra, Flipkart and Amazon sizes from one upload | verified | brand_profile |
| free-on-single-photos-no-signup-no-water | Value proposition | Free on single photos — no signup, no watermark, no daily limit | verified | brand_profile |
| photos-never-leave-the-device-everything | Value proposition | Photos never leave the device; everything runs in the browser | verified | brand_profile |
| fixes-the-things-that-actually-get-listi | Value proposition | Fixes the things that actually get listings rejected, in the right order | verified | brand_profile |
| one-photo-counts-once-however-many-steps | Value proposition | One photo counts once however many steps it passes through | verified | brand_profile |
| built-for-a-phone-because-that-is-what-t | Value proposition | Built for a phone, because that is what the seller has | verified | brand_profile |
| feat-free-kb-and-pixel-resizers | Feature: Free KB and pixel resizers | Resize or compress to an exact KB target, a pixel size, or a min-max range for portals that demand both bounds. | verified | brand_profile |
| feat-hd-photo-converter | Feature: HD photo converter | Upscale and sharpen a soft photo to 720p, 1080p, 1440p or 4K in the browser. | verified | brand_profile |
| feat-marketplace-image-tools | Feature: Marketplace image tools | Meesho, Flipkart and Amazon listing images at the exact required specification, including QC-safe backgrounds. | verified | brand_profile |
| feat-bulk-photo-pack | Feature: Bulk Photo Pack | Runs a whole drop through repair, four marketplace sizes, branding, format conversion, SKU renaming and a WhatsApp PDF in one pass. | verified | brand_profile |
| feat-whatsapp-catalogue | Feature: WhatsApp catalogue | Turns a folder of product photos and prices into a shareable PDF catalogue. | verified | brand_profile |
| feat-seller-calculators | Feature: Seller calculators | Commission, RTO, breakeven and shipping arithmetic for Meesho, Flipkart and Amazon. | verified | brand_profile |
| proof-single-photo-tools-are-genuinely | Proof point | Single-photo tools are genuinely free with no watermark and no signup | verified | brand_profile |
| proof-processing-happens-in-the-browse | Proof point | Processing happens in the browser via Canvas and WebGL — files are not uploaded | verified | brand_profile |
| proof-marketplace-hero-images-are-kept | Proof point | Marketplace hero images are kept clean automatically, because Meesho rejects logos and badges on catalog images | verified | brand_profile |
| proof-one-off-99-pack-rather-than-a-su | Proof point | One-off ₹99 pack rather than a subscription | verified | brand_profile |
