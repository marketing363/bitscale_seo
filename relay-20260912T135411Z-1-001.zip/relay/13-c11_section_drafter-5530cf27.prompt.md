ROLE: Section drafter. You draft EXACTLY ONE section of a larger page.
FULL PAGE OUTLINE (every section on the page, with its id + heading): [{"id": "answer", "h2": "The short answer"}, {"id": "canva_wins", "h2": "What Canva is genuinely better at"}, {"id": "two_jobs", "h2": "Designing something new is not the same job as meeting a spec"}, {"id": "portal_rules", "h2": "The rules a design tool has no reason to know"}, {"id": "whole_drop", "h2": "One image, or forty"}, {"id": "objections", "h2": "Free, private, and not a subscription"}, {"id": "decision", "h2": "Which to use, and when"}]
YOU ARE WRITING THIS SECTION ID: answer
INPUT SECTION SPEC: {"id": "answer", "h2": "The short answer", "word_budget": 70, "intent": "Answer-first verdict, quotable standing alone. Two different jobs: a design tool composes something new, a listing image takes an existing photograph to an exact specification with nothing added. Name who should stay on Canva in the same breath.", "entities_assigned": ["Canva", "primary image", "marketplace listing", "specification"], "facts_needed": ["proof-marketplace-hero-images-are-kept"], "keep_items_assigned": []}
BRAND VOICE: {"tone": "Plain, concrete, and on the seller's side. Names the problem in the seller's own terms before naming any feature. Concedes what a competing tool genuinely does better rather than claiming everything.", "person": "Second person to the seller ('you'), first person plural sparingly for the product. Never third-person corporate.", "sentence_rhythm": "Short declarative openers followed by a longer explanatory sentence. Varied length; no stacked equal-length sentences. Paragraphs of three to four sentences.", "words_to_use": ["listing", "catalog", "catalogue", "drop", "SKU", "QC", "rejected", "primary image", "portal", "spec", "resize", "KB limit", "phone", "rupees", "seller", "Meesho", "Flipkart", "Amazon", "Myntra", "WhatsApp"], "words_to_avoid": ["AI-powered", "revolutionary", "seamless", "effortless", "game-changing", "unlock", "supercharge", "subscription", "per month", "dollars", "$", "leverage", "solution"], "notes": "Hinglish is welcome where a seller would genuinely search in it. Currency is INR. Examples must be Indian marketplaces, never US ones."}
MUST-MIRROR PHRASES (real buyer vocabulary from GSC — use naturally, keep the commercial framing, do NOT drift into explaining the concept): []

ANTI-REPETITION (critical — the page is graded on information gain):
- Other sections (listed in the outline) OWN their topics. Do NOT re-explain the core concept, re-list the same items, or restate definitions a sibling section already covers. Advance the argument; add NEW information in your section.
- Assume the reader has read the sections above yours. Build on them, don't recap.

TASK: Draft this one section: h2 as specified, hit the word budget +-15%, cover every assigned entity and keep item, cite every number to a ledger fact inline (fact:id). Prefer concrete specifics — a real example, a data point, a named source — over generic assertions. A fact you need but do not have => write [VERIFY: what is needed] in place. Markdown body only.
OUTPUT: JSON with keys section_id, h2, body_md, entities_covered (list), verify_flags (list).

STYLE — HARD CONSTRAINTS (the draft is auto-rejected if violated):
- BANNED phrases — never write any of these (or their variants): "delve into", "in today's world/landscape/era", "in the era of", "navigate", "leverage/leverages", "unlock the power", "at the heart of", "ever-evolving", "seamless/seamlessly", "strategic blind spot", "flying blind", "fundamentally", "reshaping", "transforms X into", "game-changing", "cutting-edge", "in conclusion", "harnessing", "paradigm shift", "the world of", "a new/brave world/era", "in this article", "operating without", "stand out/standout", "robust solution/platform". Write plainly and specifically instead.
- Vary sentence openers; do not start 3+ sentences with the same word (e.g. "This").
- Do NOT use absolute words ("every", "all", "first", "only", "always") unless the claim is tied to a (fact:id) or carries a [VERIFY] flag.
- When you cite a fact that enumerates specific items (e.g. a feature listing "H1/H2 structure, tables, numbers, FAQs"), name those exact items verbatim in the sentence that carries the (fact:id).

RULES (non-negotiable):
- Assert only facts present in the FACTS LEDGER below or directly quoted from CANONICAL SOURCES.
- A missing fact must be written as [VERIFY: what is missing]. Never invent a number, source, feature, credential, quote, or URL.
- When citing a ledger fact inline, append its id like (fact:engines-count).
- Output ONLY the JSON object matching the schema given. No prose around it.
FACTS LEDGER:
| id | claim | value | status | source |
|---|---|---|---|---|
| exact-meesho-myntra-flipkart-and-amazon- | Value proposition | Exact Meesho, Myntra, Flipkart and Amazon sizes from one upload | verified | brand_profile |
| free-on-single-photos-no-signup-no-water | Value proposition | Free on single photos — no signup, no watermark, no daily limit | verified | brand_profile |
| photos-never-leave-the-device-everything | Value proposition | Photos never leave the device; everything runs in the browser | verified | brand_profile |
| fixes-the-things-that-actually-get-listi | Value proposition | Fixes the things that actually get listings rejected, in the right order | verified | brand_profile |
| one-photo-counts-once-however-many-steps | Value proposition | One photo counts once however many steps it passes through | verified | brand_profile |
| built-for-a-phone-because-that-is-what-t | Value proposition | Built for a phone, because that is what the seller has | verified | brand_profile |
| feat-free-kb-and-pixel-resizers | Feature: Free KB and pixel resizers | Resize or compress to an exact KB target, a pixel size, or a min-max range for portals that demand both bounds. | verified | brand_profile |
| feat-hd-photo-converter | Feature: HD photo converter | Upscale and sharpen a soft photo to 720p, 1080p, 1440p or 4K in the browser. | verified | brand_profile |
| feat-marketplace-image-tools | Feature: Marketplace image tools | Meesho, Flipkart and Amazon listing images at the exact required specification, including QC-safe backgrounds. | verified | brand_profile |
| feat-bulk-photo-pack | Feature: Bulk Photo Pack | Runs a whole drop through repair, four marketplace sizes, branding, format conversion, SKU renaming and a WhatsApp PDF in one pass. | verified | brand_profile |
| feat-whatsapp-catalogue | Feature: WhatsApp catalogue | Turns a folder of product photos and prices into a shareable PDF catalogue. | verified | brand_profile |
| feat-seller-calculators | Feature: Seller calculators | Commission, RTO, breakeven and shipping arithmetic for Meesho, Flipkart and Amazon. | verified | brand_profile |
| proof-single-photo-tools-are-genuinely | Proof point | Single-photo tools are genuinely free with no watermark and no signup | verified | brand_profile |
| proof-processing-happens-in-the-browse | Proof point | Processing happens in the browser via Canvas and WebGL — files are not uploaded | verified | brand_profile |
| proof-marketplace-hero-images-are-kept | Proof point | Marketplace hero images are kept clean automatically, because Meesho rejects logos and badges on catalog images | verified | brand_profile |
| proof-one-off-99-pack-rather-than-a-su | Proof point | One-off ₹99 pack rather than a subscription | verified | brand_profile |
