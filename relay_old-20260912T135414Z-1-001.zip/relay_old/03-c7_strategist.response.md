{
  "unique_insight": "Canva and a listing tool are not competing at the same job, and the seller only discovers this at QC. Canva is built to design something new - to add, arrange and decorate. A marketplace primary image is judged on the opposite: an existing photograph, at an exact pixel size and file size, with nothing added to it at all. Every instinct a design tool trains (put the shop name on it, add a festive frame, make a collage of the range) is a documented rejection reason (fact:proof-marketplace-hero-images-are-kept). So the seller who is best at Canva often gets rejected most, and the page that says this plainly owns a query no design-tool comparison currently answers.",
  "strategy": {
    "target_reader": "An Indian marketplace seller, usually on a phone, who already uses Canva competently for social posts and has started using it for listing images. Her catalogs are being rejected and she does not know that her Canva habits are the cause. She is not looking to stop using Canva; she is looking to stop being rejected.",
    "promise": "You will leave knowing which of the two jobs you are doing, which tool each job needs, and exactly which Canva habits are getting your catalog rejected.",
    "proof_order": [
      "1. Concede first: name what Canva is genuinely better at, before any claim of our own. A comparison page that concedes nothing reads as marketing and earns neither the ranking nor the trust.",
      "2. Then the structural distinction: designing something new versus taking an existing photo to a spec. This is the page's owned idea.",
      "3. Then the concrete portal constraints a design tool has no reason to know - pixel dimensions, file size, aspect ratio, and a clean primary image (fact:feat-marketplace-image-tools).",
      "4. Then scale: one image versus a whole drop (fact:feat-bulk-photo-pack).",
      "5. Then the objections, answered plainly: is it free (fact:free-on-single-photos-no-signup-no-water), do my photos get uploaded (fact:photos-never-leave-the-device-everything), is it a subscription (fact:proof-one-off-99-pack-rather-than-a-su).",
      "6. Close with a decision rule the reader can apply the same evening, naming Canva as the right answer in half the cases."
    ]
  },
  "keep_plan": [],
  "link_outs": [
    {"target": "/compare/photoroom-alternative-for-sellers", "reason": "Background removal is that page's territory. This page must reference it and move on, never re-argue it - the two would cannibalise each other otherwise.", "anchor_intent": "background removal specifically"},
    {"target": "/marketplace/meesho-image-guide", "reason": "The full Meesho image specification lives there. This page states that a spec exists and why it matters, and links rather than reproducing it.", "anchor_intent": "the Meesho image spec in full"},
    {"target": "/image-resizer", "reason": "Primary CTA. The free resizer is the thing the reader should try, and it is the direct answer to the pixel-and-KB problem the page describes.", "anchor_intent": "resize a photo to a portal spec"},
    {"target": "/image-compressor", "reason": "The file-size half of the same problem, where a portal sets a KB ceiling separately from dimensions.", "anchor_intent": "get a photo under a KB limit"},
    {"target": "/tools/meesho-image-resizer", "reason": "The Meesho-specific instance of the resize job, for a reader who sells only there.", "anchor_intent": "Meesho listing size"},
    {"target": "/tools/meesho-catalog-maker", "reason": "For the reader whose problem is a whole catalog rather than one image.", "anchor_intent": "build a whole catalog"},
    {"target": "/pricing", "reason": "Where the one-off pack terms are stated. Referenced when the bulk section raises cost, so the claim is checkable.", "anchor_intent": "what the pack costs"}
  ],
  "claims": [
    "Marketplace hero images are kept clean automatically, because Meesho rejects logos and badges on catalog images (fact:proof-marketplace-hero-images-are-kept)",
    "Meesho, Flipkart and Amazon listing images are produced at the exact required specification, including QC-safe backgrounds (fact:feat-marketplace-image-tools)",
    "Exact Meesho, Myntra, Flipkart and Amazon sizes come from one upload (fact:exact-meesho-myntra-flipkart-and-amazon-)",
    "Resize or compress to an exact KB target, a pixel size, or a min-max range for portals that demand both bounds (fact:feat-free-kb-and-pixel-resizers)",
    "A whole drop runs through repair, four marketplace sizes, branding, format conversion, SKU renaming and a WhatsApp PDF in one pass (fact:feat-bulk-photo-pack)",
    "Single photo tools are free with no signup, no watermark and no daily limit (fact:free-on-single-photos-no-signup-no-water)",
    "Processing happens in the browser via Canvas and WebGL, so files are not uploaded (fact:proof-processing-happens-in-the-browse)",
    "Photos never leave the device; everything runs in the browser (fact:photos-never-leave-the-device-everything)",
    "The pack is a one-off Rs 99 rather than a subscription (fact:proof-one-off-99-pack-rather-than-a-su)",
    "One photo counts once however many steps it passes through (fact:one-photo-counts-once-however-many-steps)",
    "Built for a phone, because that is what the seller has (fact:built-for-a-phone-because-that-is-what-t)",
    "A folder of product photos and prices becomes a shareable PDF catalogue (fact:feat-whatsapp-catalogue)"
  ],
  "scope_fence": [
    "No Canva capability, limit, plan name or price may be asserted anywhere on this page. canonical_page_texts was empty and no canonical Canva source was supplied, so every specific claim about Canva must be written as [VERIFY: ...] or kept at the level of what design tools are for as a category.",
    "Background removal belongs to /compare/photoroom-alternative-for-sellers. Reference and link; do not argue it here.",
    "The full Meesho image specification belongs to /marketplace/meesho-image-guide. State that a spec exists and why both dimensions and file size matter; do not reproduce the numbers here.",
    "No marketplace commission, shipping slab or penalty figure appears on this page - it is not a pricing page and those numbers move.",
    "Never claim an image changes a marketplace's shipping charge; shipping is billed on chargeable weight.",
    "The HD converter must not be presented as fixing blur; that routes to the AI upscaler.",
    "No testimonial, author credential or seller quote may appear - none exists with permission."
  ]
}
