"""c8_brief_compiler (L1): the working brief (structure, budgets, UI limits).

Seeds the brief from the page-type profile so every type gets its required
shape (comparison→table+verdict, glossary→definition-first, …). The model may
enrich the structure but cannot drop a required block — c8 re-merges the
profile's required blocks back in deterministically.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

import yaml

from ledger import FactsLedger
from llm import call_node
from page_profiles import get_profile

_CFG = yaml.safe_load((Path(__file__).parents[2] / "config.yaml").read_text())


def run(state: dict) -> dict:
    led = FactsLedger(list(state.get("facts_ledger", [])))
    profile = get_profile(state.get("page_type"))
    wb = profile.word_budget
    required = [{"id": b.id, "intent": b.label} for b in profile.required_blocks()]

    # Structural flexibility: the template is the FLOOR, not the ceiling.
    # Surface candidate ADDITIONS from research so the strategist can extend
    # the structure when competitor coverage or current trends call for it.
    gap = state.get("gap_entity_matrix") or {}
    template_blob = " ".join(b.label.lower() + " " + b.id.lower() for b in profile.required_blocks())
    candidate_additions = [
        s for s in (gap.get("missing_subtopics") or [])
        if isinstance(s, str) and not any(w in template_blob for w in s.lower().split()[:2])
    ][:8]
    # owner-supplied "what's happening now" — brand_profile or inputs.json
    trend_signals = (state.get("brand_profile") or {}).get("trend_signals") or \
                    (state.get("research_dossier") or {}).get("trend_signals") or []

    out = call_node(
        "c8_brief_compiler", "fast",
        primary_keyword=(state.get("intent_contract") or {}).get("primary_keyword", ""),
        strategy=json.dumps(state.get("strategy", {})),
        unique_insight=state.get("unique_insight", ""),
        page_type=state.get("page_type", ""),
        word_budget=json.dumps(wb),
        ui_limits=json.dumps(_CFG["ui_limits"]),
        serp_feature_targets=json.dumps(state.get("serp_feature_targets") or list(profile.serp_targets)),
        gap_entity_matrix=json.dumps(state.get("gap_entity_matrix", {})),
        required_blocks=json.dumps(required),
        candidate_additions=json.dumps(candidate_additions),
        trend_signals=json.dumps(trend_signals),
        schema_types=json.dumps(list(profile.schema_types)),
        ledger_markdown=led.to_markdown(),
    )
    brief = out.get("brief", out)
    if not isinstance(brief, dict):   # real models sometimes return a list/string
        brief = {"structure": brief if isinstance(brief, list) else []}

    # CONTRACT: the brief's structure must contain every required block for this
    # page type. Merge the model's structure with the profile, model order first.
    # structure items may come back as strings or dicts — normalize to dicts
    raw_structure = brief.get("structure") or []
    if not isinstance(raw_structure, list):
        raw_structure = []
    model_structure = [{"intent": s} if isinstance(s, str) else s
                       for s in raw_structure if isinstance(s, (str, dict))]
    have = {str(s.get("id") or s.get("intent", "")).lower() for s in model_structure}
    merged = list(model_structure)
    for b in profile.required_blocks():
        if b.id.lower() not in have and b.label.lower() not in have:
            merged.append({"id": b.id, "intent": b.label, "required": True})
    brief["structure"] = merged
    brief.setdefault("schema_types", list(profile.schema_types))
    brief.setdefault("word_budget", wb)
    brief["page_profile"] = profile.page_type

    # Deterministic H1 keyword backstop (governed pages): the Intent-Fit gate
    # requires the H1/title to carry >=50% of the primary-keyword terms. Models
    # sometimes paraphrase it away; ensure it is present without relaxing the gate.
    pk = (state.get("intent_contract") or {}).get("primary_keyword", "")
    if pk:
        terms = [t for t in re.split(r"\W+", pk.lower()) if t]
        title = str(brief.get("title_direction") or "").strip()
        present = sum(1 for t in terms if re.search(rf"\b{re.escape(t)}\b", title.lower()))
        if not terms or present / len(terms) < 0.5:
            kw = pk.strip().title()
            base = title or str(brief.get("meta_direction") or "").strip()
            new = f"{kw}: {base}".strip().rstrip(":").strip()
            brief["title_direction"] = new[:60].rstrip(" -:—")

    return {"brief": brief,
            "_guardrails": [{"check": "brief_compiled", "page_type": profile.page_type,
                             "structure_blocks": len(merged),
                             "required_blocks": [b.id for b in profile.required_blocks()]}]}
