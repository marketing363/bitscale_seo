# Run log

- total cost: **$0.0** (budget $3.0)
- total node time: **10.8s** (budget 15 min)
- route-back counts: {'L3': 2}

## c0_intake_router
- output keys: human_checkpoints
- duration: 0.0 ms
- guardrail: {'check': 'intake_required_inputs', 'status': 'pass'}

## c1_source_reconciler
- output keys: conflicts, facts_ledger
- duration: 1.4 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'seed_ledger', 'facts': 16, 'conflicts': 0}

## c2_cannibalization
- output keys: delegate_list, intent_contract, page_intent
- duration: 759.8 ms
- guardrail: {'check': 'cannibalization', 'status': 'checked', 'overlapping': [], 'risk': 'low'}
- guardrail: {'check': 'intent_guard', 'mode': 'single-page', 'governed': False, 'page_intent': 'canva alternative for product photos', 'primary_intent_type': 'commercial', 'delegate': [], 'head_queries': 0, 'host_vs_link': []}

## c3_kw_intent_mapper
- output keys: intent, keyword_cluster, serp_analysis
- duration: 0.2 ms
- guardrail: {'check': 'keyword_research', 'source': 'stub', 'terms': 1, 'real_volumes': False}

## c4_serp_landscape
- output keys: serp_analysis, serp_feature_targets
- duration: 0.1 ms

## c5_competitor_content
- output keys: competitors, gap_entity_matrix
- duration: 0.1 ms
- guardrail: {'check': 'competitor_gaps', 'confidence': 'stub', 'note': 'stub SERP — gap derived from result titles only; competitor pages not fetched'}

## c6_brand_loader
- output keys: brand_voice, human_checkpoints
- duration: 1.2 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'testimonial_permissions', 'usable': 0, 'excluded': 0}

## c7_strategist
- output keys: strategy, unique_insight
- duration: 0.9 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'grounding_check', 'violations': []}

## c8_brief_compiler
- output keys: brief
- duration: 1.2 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'brief_compiled', 'page_type': 'comparison', 'structure_blocks': 14, 'required_blocks': ['verdict', 'at_a_glance', 'criteria', 'head_to_head', 'pros_cons', 'who_should', 'faq']}

## c9_outline
- output keys: outline
- duration: 0.9 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'entity_coverage', 'unassigned': [], 'sections': 7}
- guardrail: {'check': 'intent_boundary', 'trespasses': []}

## c10_hook
- output keys: lead
- duration: 0.8 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'answer_first', 'words': 49, 'flag_dont_fill': []}

## c0_intake_router
- output keys: human_checkpoints
- duration: 0.0 ms
- guardrail: {'check': 'intake_required_inputs', 'status': 'pass'}

## c1_source_reconciler
- output keys: conflicts, facts_ledger
- duration: 1.5 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'seed_ledger', 'facts': 16, 'conflicts': 0}

## c2_cannibalization
- output keys: delegate_list, intent_contract, page_intent
- duration: 1457.9 ms
- guardrail: {'check': 'cannibalization', 'status': 'checked', 'overlapping': [], 'risk': 'low'}
- guardrail: {'check': 'intent_guard', 'mode': 'single-page', 'governed': False, 'page_intent': 'canva alternative for product photos', 'primary_intent_type': 'commercial', 'delegate': [], 'head_queries': 0, 'host_vs_link': []}

## c3_kw_intent_mapper
- output keys: intent, keyword_cluster, serp_analysis
- duration: 0.6 ms
- guardrail: {'check': 'keyword_research', 'source': 'stub', 'terms': 1, 'real_volumes': False}

## c4_serp_landscape
- output keys: serp_analysis, serp_feature_targets
- duration: 0.1 ms

## c5_competitor_content
- output keys: competitors, gap_entity_matrix
- duration: 0.1 ms
- guardrail: {'check': 'competitor_gaps', 'confidence': 'stub', 'note': 'stub SERP — gap derived from result titles only; competitor pages not fetched'}

## c6_brand_loader
- output keys: brand_voice, human_checkpoints
- duration: 2.7 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'testimonial_permissions', 'usable': 0, 'excluded': 0}

## c7_strategist
- output keys: strategy, unique_insight
- duration: 1.7 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'grounding_check', 'violations': []}

## c8_brief_compiler
- output keys: brief
- duration: 1.7 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'brief_compiled', 'page_type': 'comparison', 'structure_blocks': 14, 'required_blocks': ['verdict', 'at_a_glance', 'criteria', 'head_to_head', 'pros_cons', 'who_should', 'faq']}

## c9_outline
- output keys: outline
- duration: 1.4 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'entity_coverage', 'unassigned': [], 'sections': 7}
- guardrail: {'check': 'intent_boundary', 'trespasses': []}

## c10_hook
- output keys: lead
- duration: 2.1 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'answer_first', 'words': 49, 'flag_dont_fill': []}

## c0_intake_router
- output keys: human_checkpoints
- duration: 0.0 ms
- guardrail: {'check': 'intake_required_inputs', 'status': 'pass'}

## c1_source_reconciler
- output keys: conflicts, facts_ledger
- duration: 0.7 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'seed_ledger', 'facts': 16, 'conflicts': 0}

## c2_cannibalization
- output keys: delegate_list, intent_contract, page_intent
- duration: 997.0 ms
- guardrail: {'check': 'cannibalization', 'status': 'checked', 'overlapping': [], 'risk': 'low'}
- guardrail: {'check': 'intent_guard', 'mode': 'single-page', 'governed': False, 'page_intent': 'canva alternative for product photos', 'primary_intent_type': 'commercial', 'delegate': [], 'head_queries': 0, 'host_vs_link': []}

## c3_kw_intent_mapper
- output keys: intent, keyword_cluster, serp_analysis
- duration: 0.9 ms
- guardrail: {'check': 'keyword_research', 'source': 'stub', 'terms': 1, 'real_volumes': False}

## c4_serp_landscape
- output keys: serp_analysis, serp_feature_targets
- duration: 0.2 ms

## c5_competitor_content
- output keys: competitors, gap_entity_matrix
- duration: 0.2 ms
- guardrail: {'check': 'competitor_gaps', 'confidence': 'stub', 'note': 'stub SERP — gap derived from result titles only; competitor pages not fetched'}

## c6_brand_loader
- output keys: brand_voice, human_checkpoints
- duration: 1.9 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'testimonial_permissions', 'usable': 0, 'excluded': 0}

## c7_strategist
- output keys: strategy, unique_insight
- duration: 1.2 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'grounding_check', 'violations': []}

## c8_brief_compiler
- output keys: brief
- duration: 1.2 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'brief_compiled', 'page_type': 'comparison', 'structure_blocks': 14, 'required_blocks': ['verdict', 'at_a_glance', 'criteria', 'head_to_head', 'pros_cons', 'who_should', 'faq']}

## c9_outline
- output keys: outline
- duration: 1.2 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'entity_coverage', 'unassigned': [], 'sections': 7}
- guardrail: {'check': 'intent_boundary', 'trespasses': []}

## c10_hook
- output keys: lead
- duration: 0.9 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'answer_first', 'words': 49, 'flag_dont_fill': []}

## c0_intake_router
- output keys: human_checkpoints
- duration: 0.0 ms
- guardrail: {'check': 'intake_required_inputs', 'status': 'pass'}

## c1_source_reconciler
- output keys: conflicts, facts_ledger
- duration: 0.7 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'seed_ledger', 'facts': 16, 'conflicts': 0}

## c2_cannibalization
- output keys: delegate_list, intent_contract, page_intent
- duration: 776.5 ms
- guardrail: {'check': 'cannibalization', 'status': 'checked', 'overlapping': [], 'risk': 'low'}
- guardrail: {'check': 'intent_guard', 'mode': 'single-page', 'governed': False, 'page_intent': 'canva alternative for product photos', 'primary_intent_type': 'commercial', 'delegate': [], 'head_queries': 0, 'host_vs_link': []}

## c3_kw_intent_mapper
- output keys: intent, keyword_cluster, serp_analysis
- duration: 0.7 ms
- guardrail: {'check': 'keyword_research', 'source': 'stub', 'terms': 1, 'real_volumes': False}

## c4_serp_landscape
- output keys: serp_analysis, serp_feature_targets
- duration: 0.2 ms

## c5_competitor_content
- output keys: competitors, gap_entity_matrix
- duration: 0.2 ms
- guardrail: {'check': 'competitor_gaps', 'confidence': 'stub', 'note': 'stub SERP — gap derived from result titles only; competitor pages not fetched'}

## c6_brand_loader
- output keys: brand_voice, human_checkpoints
- duration: 1.5 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'testimonial_permissions', 'usable': 0, 'excluded': 0}

## c7_strategist
- output keys: strategy, unique_insight
- duration: 1.5 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'grounding_check', 'violations': []}

## c8_brief_compiler
- output keys: brief
- duration: 1.4 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'brief_compiled', 'page_type': 'comparison', 'structure_blocks': 14, 'required_blocks': ['verdict', 'at_a_glance', 'criteria', 'head_to_head', 'pros_cons', 'who_should', 'faq']}

## c9_outline
- output keys: outline
- duration: 1.0 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'entity_coverage', 'unassigned': [], 'sections': 7}
- guardrail: {'check': 'intent_boundary', 'trespasses': []}

## c10_hook
- output keys: lead
- duration: 1.0 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'answer_first', 'words': 49, 'flag_dont_fill': []}

## c0_intake_router
- output keys: human_checkpoints
- duration: 0.0 ms
- guardrail: {'check': 'intake_required_inputs', 'status': 'pass'}

## c1_source_reconciler
- output keys: conflicts, facts_ledger
- duration: 0.6 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'seed_ledger', 'facts': 16, 'conflicts': 0}

## c2_cannibalization
- output keys: delegate_list, intent_contract, page_intent
- duration: 709.4 ms
- guardrail: {'check': 'cannibalization', 'status': 'checked', 'overlapping': [], 'risk': 'low'}
- guardrail: {'check': 'intent_guard', 'mode': 'single-page', 'governed': False, 'page_intent': 'canva alternative for product photos', 'primary_intent_type': 'commercial', 'delegate': [], 'head_queries': 0, 'host_vs_link': []}

## c3_kw_intent_mapper
- output keys: intent, keyword_cluster, serp_analysis
- duration: 0.6 ms
- guardrail: {'check': 'keyword_research', 'source': 'stub', 'terms': 1, 'real_volumes': False}

## c4_serp_landscape
- output keys: serp_analysis, serp_feature_targets
- duration: 0.1 ms

## c5_competitor_content
- output keys: competitors, gap_entity_matrix
- duration: 0.1 ms
- guardrail: {'check': 'competitor_gaps', 'confidence': 'stub', 'note': 'stub SERP — gap derived from result titles only; competitor pages not fetched'}

## c6_brand_loader
- output keys: brand_voice, human_checkpoints
- duration: 1.5 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'testimonial_permissions', 'usable': 0, 'excluded': 0}

## c7_strategist
- output keys: strategy, unique_insight
- duration: 1.3 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'grounding_check', 'violations': []}

## c8_brief_compiler
- output keys: brief
- duration: 1.3 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'brief_compiled', 'page_type': 'comparison', 'structure_blocks': 14, 'required_blocks': ['verdict', 'at_a_glance', 'criteria', 'head_to_head', 'pros_cons', 'who_should', 'faq']}

## c9_outline
- output keys: outline
- duration: 1.1 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'entity_coverage', 'unassigned': [], 'sections': 7}
- guardrail: {'check': 'intent_boundary', 'trespasses': []}

## c10_hook
- output keys: lead
- duration: 1.1 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'answer_first', 'words': 49, 'flag_dont_fill': []}

## c0_intake_router
- output keys: human_checkpoints
- duration: 0.0 ms
- guardrail: {'check': 'intake_required_inputs', 'status': 'pass'}

## c1_source_reconciler
- output keys: conflicts, facts_ledger
- duration: 0.7 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'seed_ledger', 'facts': 16, 'conflicts': 0}

## c2_cannibalization
- output keys: delegate_list, intent_contract, page_intent
- duration: 796.0 ms
- guardrail: {'check': 'cannibalization', 'status': 'checked', 'overlapping': [], 'risk': 'low'}
- guardrail: {'check': 'intent_guard', 'mode': 'single-page', 'governed': False, 'page_intent': 'canva alternative for product photos', 'primary_intent_type': 'commercial', 'delegate': [], 'head_queries': 0, 'host_vs_link': []}

## c3_kw_intent_mapper
- output keys: intent, keyword_cluster, serp_analysis
- duration: 0.5 ms
- guardrail: {'check': 'keyword_research', 'source': 'stub', 'terms': 1, 'real_volumes': False}

## c4_serp_landscape
- output keys: serp_analysis, serp_feature_targets
- duration: 0.1 ms

## c5_competitor_content
- output keys: competitors, gap_entity_matrix
- duration: 0.1 ms
- guardrail: {'check': 'competitor_gaps', 'confidence': 'stub', 'note': 'stub SERP — gap derived from result titles only; competitor pages not fetched'}

## c6_brand_loader
- output keys: brand_voice, human_checkpoints
- duration: 2.0 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'testimonial_permissions', 'usable': 0, 'excluded': 0}

## c7_strategist
- output keys: strategy, unique_insight
- duration: 1.2 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'grounding_check', 'violations': []}

## c8_brief_compiler
- output keys: brief
- duration: 1.2 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'brief_compiled', 'page_type': 'comparison', 'structure_blocks': 14, 'required_blocks': ['verdict', 'at_a_glance', 'criteria', 'head_to_head', 'pros_cons', 'who_should', 'faq']}

## c9_outline
- output keys: outline
- duration: 1.3 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'entity_coverage', 'unassigned': [], 'sections': 7}
- guardrail: {'check': 'intent_boundary', 'trespasses': []}

## c10_hook
- output keys: lead
- duration: 1.1 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'answer_first', 'words': 49, 'flag_dont_fill': []}

## c0_intake_router
- output keys: human_checkpoints
- duration: 0.0 ms
- guardrail: {'check': 'intake_required_inputs', 'status': 'pass'}

## c1_source_reconciler
- output keys: conflicts, facts_ledger
- duration: 0.7 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'seed_ledger', 'facts': 16, 'conflicts': 0}

## c2_cannibalization
- output keys: delegate_list, intent_contract, page_intent
- duration: 787.5 ms
- guardrail: {'check': 'cannibalization', 'status': 'checked', 'overlapping': [], 'risk': 'low'}
- guardrail: {'check': 'intent_guard', 'mode': 'single-page', 'governed': False, 'page_intent': 'canva alternative for product photos', 'primary_intent_type': 'commercial', 'delegate': [], 'head_queries': 0, 'host_vs_link': []}

## c3_kw_intent_mapper
- output keys: intent, keyword_cluster, serp_analysis
- duration: 0.9 ms
- guardrail: {'check': 'keyword_research', 'source': 'stub', 'terms': 1, 'real_volumes': False}

## c4_serp_landscape
- output keys: serp_analysis, serp_feature_targets
- duration: 0.1 ms

## c5_competitor_content
- output keys: competitors, gap_entity_matrix
- duration: 0.2 ms
- guardrail: {'check': 'competitor_gaps', 'confidence': 'stub', 'note': 'stub SERP — gap derived from result titles only; competitor pages not fetched'}

## c6_brand_loader
- output keys: brand_voice, human_checkpoints
- duration: 1.7 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'testimonial_permissions', 'usable': 0, 'excluded': 0}

## c7_strategist
- output keys: strategy, unique_insight
- duration: 1.5 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'grounding_check', 'violations': []}

## c8_brief_compiler
- output keys: brief
- duration: 1.3 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'brief_compiled', 'page_type': 'comparison', 'structure_blocks': 14, 'required_blocks': ['verdict', 'at_a_glance', 'criteria', 'head_to_head', 'pros_cons', 'who_should', 'faq']}

## c9_outline
- output keys: outline
- duration: 1.1 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'entity_coverage', 'unassigned': [], 'sections': 7}
- guardrail: {'check': 'intent_boundary', 'trespasses': []}

## c10_hook
- output keys: lead
- duration: 1.1 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'answer_first', 'words': 49, 'flag_dont_fill': []}

## c0_intake_router
- output keys: human_checkpoints
- duration: 0.0 ms
- guardrail: {'check': 'intake_required_inputs', 'status': 'pass'}

## c1_source_reconciler
- output keys: conflicts, facts_ledger
- duration: 0.7 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'seed_ledger', 'facts': 16, 'conflicts': 0}

## c2_cannibalization
- output keys: delegate_list, intent_contract, page_intent
- duration: 847.0 ms
- guardrail: {'check': 'cannibalization', 'status': 'checked', 'overlapping': [], 'risk': 'low'}
- guardrail: {'check': 'intent_guard', 'mode': 'single-page', 'governed': False, 'page_intent': 'canva alternative for product photos', 'primary_intent_type': 'commercial', 'delegate': [], 'head_queries': 0, 'host_vs_link': []}

## c3_kw_intent_mapper
- output keys: intent, keyword_cluster, serp_analysis
- duration: 0.5 ms
- guardrail: {'check': 'keyword_research', 'source': 'stub', 'terms': 1, 'real_volumes': False}

## c4_serp_landscape
- output keys: serp_analysis, serp_feature_targets
- duration: 0.1 ms

## c5_competitor_content
- output keys: competitors, gap_entity_matrix
- duration: 0.1 ms
- guardrail: {'check': 'competitor_gaps', 'confidence': 'stub', 'note': 'stub SERP — gap derived from result titles only; competitor pages not fetched'}

## c6_brand_loader
- output keys: brand_voice, human_checkpoints
- duration: 1.3 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'testimonial_permissions', 'usable': 0, 'excluded': 0}

## c7_strategist
- output keys: strategy, unique_insight
- duration: 1.3 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'grounding_check', 'violations': []}

## c8_brief_compiler
- output keys: brief
- duration: 1.2 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'brief_compiled', 'page_type': 'comparison', 'structure_blocks': 14, 'required_blocks': ['verdict', 'at_a_glance', 'criteria', 'head_to_head', 'pros_cons', 'who_should', 'faq']}

## c9_outline
- output keys: outline
- duration: 1.0 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'entity_coverage', 'unassigned': [], 'sections': 7}
- guardrail: {'check': 'intent_boundary', 'trespasses': []}

## c10_hook
- output keys: lead
- duration: 0.9 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'answer_first', 'words': 49, 'flag_dont_fill': []}

## c0_intake_router
- output keys: human_checkpoints
- duration: 0.0 ms
- guardrail: {'check': 'intake_required_inputs', 'status': 'pass'}

## c1_source_reconciler
- output keys: conflicts, facts_ledger
- duration: 0.7 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'seed_ledger', 'facts': 16, 'conflicts': 0}

## c2_cannibalization
- output keys: delegate_list, intent_contract, page_intent
- duration: 545.4 ms
- guardrail: {'check': 'cannibalization', 'status': 'checked', 'overlapping': [], 'risk': 'low'}
- guardrail: {'check': 'intent_guard', 'mode': 'single-page', 'governed': False, 'page_intent': 'canva alternative for product photos', 'primary_intent_type': 'commercial', 'delegate': [], 'head_queries': 0, 'host_vs_link': []}

## c3_kw_intent_mapper
- output keys: intent, keyword_cluster, serp_analysis
- duration: 0.5 ms
- guardrail: {'check': 'keyword_research', 'source': 'stub', 'terms': 1, 'real_volumes': False}

## c4_serp_landscape
- output keys: serp_analysis, serp_feature_targets
- duration: 0.2 ms

## c5_competitor_content
- output keys: competitors, gap_entity_matrix
- duration: 0.1 ms
- guardrail: {'check': 'competitor_gaps', 'confidence': 'stub', 'note': 'stub SERP — gap derived from result titles only; competitor pages not fetched'}

## c6_brand_loader
- output keys: brand_voice, human_checkpoints
- duration: 1.3 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'testimonial_permissions', 'usable': 0, 'excluded': 0}

## c7_strategist
- output keys: strategy, unique_insight
- duration: 0.9 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'grounding_check', 'violations': []}

## c8_brief_compiler
- output keys: brief
- duration: 1.0 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'brief_compiled', 'page_type': 'comparison', 'structure_blocks': 14, 'required_blocks': ['verdict', 'at_a_glance', 'criteria', 'head_to_head', 'pros_cons', 'who_should', 'faq']}

## c9_outline
- output keys: outline
- duration: 0.9 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'entity_coverage', 'unassigned': [], 'sections': 7}
- guardrail: {'check': 'intent_boundary', 'trespasses': []}

## c10_hook
- output keys: lead
- duration: 0.9 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'answer_first', 'words': 49, 'flag_dont_fill': []}

## c11_section_drafter
- output keys: sections
- duration: 6.2 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- model call: None — 0 in / 0 out ($0.0)
- model call: None — 0 in / 0 out ($0.0)
- model call: None — 0 in / 0 out ($0.0)
- model call: None — 0 in / 0 out ($0.0)
- model call: None — 0 in / 0 out ($0.0)
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'flag_dont_fill', 'sections': 7, 'violations': []}

## c0_intake_router
- output keys: human_checkpoints
- duration: 0.0 ms
- guardrail: {'check': 'intake_required_inputs', 'status': 'pass'}

## c1_source_reconciler
- output keys: conflicts, facts_ledger
- duration: 1.2 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'seed_ledger', 'facts': 16, 'conflicts': 0}

## c2_cannibalization
- output keys: delegate_list, intent_contract, page_intent
- duration: 1435.2 ms
- guardrail: {'check': 'cannibalization', 'status': 'checked', 'overlapping': [], 'risk': 'low'}
- guardrail: {'check': 'intent_guard', 'mode': 'single-page', 'governed': False, 'page_intent': 'canva alternative for product photos', 'primary_intent_type': 'commercial', 'delegate': [], 'head_queries': 0, 'host_vs_link': []}

## c3_kw_intent_mapper
- output keys: intent, keyword_cluster, serp_analysis
- duration: 0.3 ms
- guardrail: {'check': 'keyword_research', 'source': 'stub', 'terms': 1, 'real_volumes': False}

## c4_serp_landscape
- output keys: serp_analysis, serp_feature_targets
- duration: 0.1 ms

## c5_competitor_content
- output keys: competitors, gap_entity_matrix
- duration: 0.1 ms
- guardrail: {'check': 'competitor_gaps', 'confidence': 'stub', 'note': 'stub SERP — gap derived from result titles only; competitor pages not fetched'}

## c6_brand_loader
- output keys: brand_voice, human_checkpoints
- duration: 1.4 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'testimonial_permissions', 'usable': 0, 'excluded': 0}

## c7_strategist
- output keys: strategy, unique_insight
- duration: 1.1 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'grounding_check', 'violations': []}

## c8_brief_compiler
- output keys: brief
- duration: 2.2 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'brief_compiled', 'page_type': 'comparison', 'structure_blocks': 14, 'required_blocks': ['verdict', 'at_a_glance', 'criteria', 'head_to_head', 'pros_cons', 'who_should', 'faq']}

## c9_outline
- output keys: outline
- duration: 1.1 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'entity_coverage', 'unassigned': [], 'sections': 7}
- guardrail: {'check': 'intent_boundary', 'trespasses': []}

## c10_hook
- output keys: lead
- duration: 0.9 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'answer_first', 'words': 49, 'flag_dont_fill': []}

## c11_section_drafter
- output keys: sections
- duration: 4.9 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- model call: None — 0 in / 0 out ($0.0)
- model call: None — 0 in / 0 out ($0.0)
- model call: None — 0 in / 0 out ($0.0)
- model call: None — 0 in / 0 out ($0.0)
- model call: None — 0 in / 0 out ($0.0)
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'flag_dont_fill', 'sections': 7, 'violations': []}

## c0_intake_router
- output keys: human_checkpoints
- duration: 0.0 ms
- guardrail: {'check': 'intake_required_inputs', 'status': 'pass'}

## c1_source_reconciler
- output keys: conflicts, facts_ledger
- duration: 1.0 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'seed_ledger', 'facts': 16, 'conflicts': 0}

## c2_cannibalization
- output keys: delegate_list, intent_contract, page_intent
- duration: 1445.5 ms
- guardrail: {'check': 'cannibalization', 'status': 'checked', 'overlapping': [], 'risk': 'low'}
- guardrail: {'check': 'intent_guard', 'mode': 'single-page', 'governed': False, 'page_intent': 'canva alternative for product photos', 'primary_intent_type': 'commercial', 'delegate': [], 'head_queries': 0, 'host_vs_link': []}

## c3_kw_intent_mapper
- output keys: intent, keyword_cluster, serp_analysis
- duration: 0.7 ms
- guardrail: {'check': 'keyword_research', 'source': 'stub', 'terms': 1, 'real_volumes': False}

## c4_serp_landscape
- output keys: serp_analysis, serp_feature_targets
- duration: 0.1 ms

## c5_competitor_content
- output keys: competitors, gap_entity_matrix
- duration: 0.1 ms
- guardrail: {'check': 'competitor_gaps', 'confidence': 'stub', 'note': 'stub SERP — gap derived from result titles only; competitor pages not fetched'}

## c6_brand_loader
- output keys: brand_voice, human_checkpoints
- duration: 2.2 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'testimonial_permissions', 'usable': 0, 'excluded': 0}

## c7_strategist
- output keys: strategy, unique_insight
- duration: 1.6 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'grounding_check', 'violations': []}

## c8_brief_compiler
- output keys: brief
- duration: 1.7 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'brief_compiled', 'page_type': 'comparison', 'structure_blocks': 14, 'required_blocks': ['verdict', 'at_a_glance', 'criteria', 'head_to_head', 'pros_cons', 'who_should', 'faq']}

## c9_outline
- output keys: outline
- duration: 1.4 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'entity_coverage', 'unassigned': [], 'sections': 7}
- guardrail: {'check': 'intent_boundary', 'trespasses': []}

## c10_hook
- output keys: lead
- duration: 1.5 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'answer_first', 'words': 49, 'flag_dont_fill': []}

## c11_section_drafter
- output keys: sections
- duration: 6.7 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- model call: None — 0 in / 0 out ($0.0)
- model call: None — 0 in / 0 out ($0.0)
- model call: None — 0 in / 0 out ($0.0)
- model call: None — 0 in / 0 out ($0.0)
- model call: None — 0 in / 0 out ($0.0)
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'flag_dont_fill', 'sections': 7, 'violations': []}

## c12_faq
- output keys: faq
- duration: 0.9 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'faq', 'count': 6}

## c13_evidence
- output keys: facts_ledger, human_checkpoints, verify_list
- duration: 5.0 ms
- guardrail: {'check': 'evidence', 'flags': 0, 'resolved': 0, 'needs_user': 0, 'unresolved': 0, 'tool': 'web-fetch/RAG'}

## c14_eeat
- output keys: human_checkpoints
- duration: 0.0 ms
- guardrail: {'check': 'eeat_from_brand_assets_only', 'author': False, 'testimonials_used': 0, 'testimonials_excluded': 0}

## c15_media
- output keys: human_checkpoints, media_manifest, svg_assets
- duration: 0.0 ms
- guardrail: {'check': 'media', 'items': 1, 'base64': 0, 'ok': True}

## c16_editorial
- output keys: draft, human_checkpoints
- duration: 10.4 ms
- guardrail: {'check': 'no_new_facts', 'new_numbers': [], 'ok': True}
- guardrail: {'check': 'cut_unverified', 'count': 0}
- guardrail: {'check': 'dedupe_repeats', 'removed': 2}

## c17_a11y_perf
- output keys: (none)
- duration: 0.1 ms
- guardrail: {'check': 'a11y_perf', 'violations': [], 'ok': True}

## c18_schema
- output keys: schema_jsonld
- duration: 0.0 ms
- guardrail: {'check': 'schema', 'page_type': 'comparison', 'types': ['WebPage', 'FAQPage'], 'approved_reviews': 0}

## c19_critic
- output keys: critic_report
- duration: 14.4 ms
- guardrail: {'check': 'critic', 'verdict': 'fail', 'failures': 7, 'info_gain_score': 28, 'info_gain_enforced': True}

## c20_render_critic
- output keys: render_report
- duration: 2.7 ms
- guardrail: {'check': 'render_critic', 'verdict': 'pass', 'failures': 19}

## c21_comparison_judge
- output keys: comparison_report
- duration: 0.0 ms

## c10_hook
- output keys: lead
- duration: 0.2 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'answer_first', 'words': 49, 'flag_dont_fill': []}

## c11_section_drafter
- output keys: sections
- duration: 3.3 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- model call: None — 0 in / 0 out ($0.0)
- model call: None — 0 in / 0 out ($0.0)
- model call: None — 0 in / 0 out ($0.0)
- model call: None — 0 in / 0 out ($0.0)
- model call: None — 0 in / 0 out ($0.0)
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'flag_dont_fill', 'sections': 7, 'violations': []}

## c12_faq
- output keys: faq
- duration: 0.3 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'faq', 'count': 6}

## c13_evidence
- output keys: facts_ledger, human_checkpoints, verify_list
- duration: 3.3 ms
- guardrail: {'check': 'evidence', 'flags': 0, 'resolved': 0, 'needs_user': 0, 'unresolved': 0, 'tool': 'web-fetch/RAG'}

## c14_eeat
- output keys: human_checkpoints
- duration: 0.0 ms
- guardrail: {'check': 'eeat_from_brand_assets_only', 'author': False, 'testimonials_used': 0, 'testimonials_excluded': 0}

## c15_media
- output keys: human_checkpoints, media_manifest, svg_assets
- duration: 0.0 ms
- guardrail: {'check': 'media', 'items': 1, 'base64': 0, 'ok': True}

## c16_editorial
- output keys: draft, human_checkpoints
- duration: 7.3 ms
- guardrail: {'check': 'no_new_facts', 'new_numbers': [], 'ok': True}
- guardrail: {'check': 'cut_unverified', 'count': 0}
- guardrail: {'check': 'dedupe_repeats', 'removed': 2}

## c17_a11y_perf
- output keys: (none)
- duration: 0.1 ms
- guardrail: {'check': 'a11y_perf', 'violations': [], 'ok': True}

## c18_schema
- output keys: schema_jsonld
- duration: 0.0 ms
- guardrail: {'check': 'schema', 'page_type': 'comparison', 'types': ['WebPage', 'FAQPage'], 'approved_reviews': 0}

## c19_critic
- output keys: critic_report
- duration: 9.2 ms
- guardrail: {'check': 'critic', 'verdict': 'fail', 'failures': 7, 'info_gain_score': 28, 'info_gain_enforced': True}

## c20_render_critic
- output keys: render_report
- duration: 2.1 ms
- guardrail: {'check': 'render_critic', 'verdict': 'pass', 'failures': 19}

## c21_comparison_judge
- output keys: comparison_report
- duration: 0.0 ms

## c10_hook
- output keys: lead
- duration: 0.3 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'answer_first', 'words': 49, 'flag_dont_fill': []}

## c11_section_drafter
- output keys: sections
- duration: 3.5 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- model call: None — 0 in / 0 out ($0.0)
- model call: None — 0 in / 0 out ($0.0)
- model call: None — 0 in / 0 out ($0.0)
- model call: None — 0 in / 0 out ($0.0)
- model call: None — 0 in / 0 out ($0.0)
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'flag_dont_fill', 'sections': 7, 'violations': []}

## c12_faq
- output keys: faq
- duration: 0.3 ms · cost: $0.0
- model call: None — 0 in / 0 out ($0.0)
- guardrail: {'check': 'faq', 'count': 6}

## c13_evidence
- output keys: facts_ledger, human_checkpoints, verify_list
- duration: 3.2 ms
- guardrail: {'check': 'evidence', 'flags': 0, 'resolved': 0, 'needs_user': 0, 'unresolved': 0, 'tool': 'web-fetch/RAG'}

## c14_eeat
- output keys: human_checkpoints
- duration: 0.0 ms
- guardrail: {'check': 'eeat_from_brand_assets_only', 'author': False, 'testimonials_used': 0, 'testimonials_excluded': 0}

## c15_media
- output keys: human_checkpoints, media_manifest, svg_assets
- duration: 0.0 ms
- guardrail: {'check': 'media', 'items': 1, 'base64': 0, 'ok': True}

## c16_editorial
- output keys: draft, human_checkpoints
- duration: 6.9 ms
- guardrail: {'check': 'no_new_facts', 'new_numbers': [], 'ok': True}
- guardrail: {'check': 'cut_unverified', 'count': 0}
- guardrail: {'check': 'dedupe_repeats', 'removed': 2}

## c17_a11y_perf
- output keys: (none)
- duration: 0.1 ms
- guardrail: {'check': 'a11y_perf', 'violations': [], 'ok': True}

## c18_schema
- output keys: schema_jsonld
- duration: 0.0 ms
- guardrail: {'check': 'schema', 'page_type': 'comparison', 'types': ['WebPage', 'FAQPage'], 'approved_reviews': 0}

## c19_critic
- output keys: critic_report
- duration: 9.2 ms
- guardrail: {'check': 'critic', 'verdict': 'fail', 'failures': 7, 'info_gain_score': 28, 'info_gain_enforced': True}

## c20_render_critic
- output keys: render_report
- duration: 2.0 ms
- guardrail: {'check': 'render_critic', 'verdict': 'pass', 'failures': 19}

## c21_comparison_judge
- output keys: comparison_report
- duration: 0.0 ms

