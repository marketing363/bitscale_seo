{
  "lead": "Canva and a listing tool do different jobs. Canva composes something new; a marketplace primary image is an existing photograph taken to an exact size with nothing added to it. If your catalogs keep getting rejected, that habit of adding is usually why (fact:proof-marketplace-hero-images-are-kept). Keep Canva for social posts.",
  "word_count": 48
}
