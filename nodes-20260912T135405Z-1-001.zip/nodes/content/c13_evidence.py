"""c13_evidence (L4): the verifier (≠ writer).

Now backed by a real retrieval tool. For every `[VERIFY:]` flag in the draft it
asks tools.evidence to find a real citation (SERP → fetch → extract). Outcomes:
  - resolved          → recorded as a sourced fact in state; flag cleared.
  - needs_user_input  → routed to the brand brain as a data_request (UI answers).
  - unresolved        → kept as a human checkpoint (never fabricated, never dropped).

Honest degradation: if the evidence tool is disabled or the web is unreachable,
every flag falls back to 'keep-flagged' — exactly the pre-tool behaviour.
"""
from __future__ import annotations

from guardrails import VERIFY_PAT


def _load_cfg():
    try:
        import yaml
        from pathlib import Path
        return yaml.safe_load((Path(__file__).resolve().parents[2] / "config.yaml").read_text())
    except Exception:
        return {}


def run(state: dict) -> dict:
    texts = [state.get("lead", "")]
    texts += list((state.get("sections") or {}).values())
    texts += [f.get("a", "") for f in (state.get("faq") or [])]

    flags: list[str] = []
    for t in texts:
        flags += VERIFY_PAT.findall(t or "")

    cfg = _load_cfg()
    domain = state.get("domain") or (state.get("account") or {}).get("domain") or "unknown"
    evidence_enabled = (cfg.get("tools", {}).get("evidence") or {}).get("enabled", False)

    hc = list(state.get("human_checkpoints", []))
    verdicts = []
    resolved_facts = list(state.get("facts_ledger", []))
    resolved_n = user_n = unresolved_n = 0

    resolutions = []
    if flags and evidence_enabled:
        try:
            from tools.evidence import resolve_flags
            resolutions = resolve_flags(domain, flags, cfg=cfg)
        except Exception as e:  # network down / tool error → behave as before
            resolutions = []
            hc.append(f"[NOTE] evidence tool unavailable ({type(e).__name__}); flags kept for human.")

    res_by_flag = {r["flag"]: r for r in resolutions}
    for flag in flags:
        r = res_by_flag.get(flag)
        if r and r.get("status") == "resolved":
            resolved_n += 1
            verdicts.append({"flag": flag, "verdict": "resolved",
                             "source_url": r.get("source_url"), "passage": r.get("passage")})
            resolved_facts.append({
                "id": f"ev-{abs(hash(flag)) % 10**8}",
                "claim": r.get("passage", "")[:240],
                "value": "", "source": "external", "source_url": r.get("source_url"),
                "provenance": "resolved by c13 web-fetch/RAG"})
        elif r and r.get("status") == "needs_user_input":
            user_n += 1
            verdicts.append({"flag": flag, "verdict": "needs_user_input"})
            hc.append(f"[HUMAN] Supply via UI (no web source — internal data): {flag}")
        else:
            unresolved_n += 1
            verdicts.append({"flag": flag, "verdict": "keep-flagged",
                             "note": "no automated source found; needs human"})
            hc.append(f"[HUMAN] Resolve evidence flag (no automated source yet): {flag}")

    return {
        "verify_list": flags,
        "facts_ledger": resolved_facts,
        "human_checkpoints": hc,
        "_c13_verdicts": verdicts,
        "_guardrails": [{"check": "evidence", "flags": len(flags),
                         "resolved": resolved_n, "needs_user": user_n,
                         "unresolved": unresolved_n,
                         "tool": "web-fetch/RAG" if evidence_enabled else "off"}],
    }
