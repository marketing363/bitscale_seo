{"proposed_facts": [], "unresolved": []}
