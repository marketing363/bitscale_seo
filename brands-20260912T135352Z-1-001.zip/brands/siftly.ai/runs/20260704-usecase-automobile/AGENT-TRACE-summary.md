# /use-cases/automobile — Agent trace

**Brand:** siftly.ai  
**Page:** `/use-cases/automobile` — Siftly's use-case landing for the automobile vertical, anchored on the Maruti Suzuki × Siftly MSIP Cohort 5 partnership (published on Siftly's blog 29 June 2026).  
**Mode:** `content --mode net_new` (net-new page from a seed keyword; no prior URL to rebuild)  
**Model provider:** `--fake` (scripted offline LLM) — so no API key was needed; the run demonstrates that every agent in the graph fires and every guardrail is exercised.  
**Route-back cap:** 2 (from `config.yaml`) — hit and escalated as designed.

---

## Inputs

- **Seed keyword:** `generative engine optimization tools for the automotive industry` (Vol 20, Semrush — from the uploaded Siftly Keyword Target Master, sheet `generative-engine-optimization`)
- **Secondary long-tails pulled from the same sheet:**
  - `generative engine optimization tips for automotive manufacturers` (Vol 10)
  - `how do automotive brands monitor ai search results brand positioning` (Vol 20)
  - `automotive share of voice reports`, `vehicle share of voice reports`
  - `best generative engine optimization software automotive parts e-commerce us 2025` (Vol 10)
- **Cluster context:** pillar `/use-cases`, siblings `/use-cases/{saas,agencies,legal,fintech,healthcare}` — the intent-boundary guard treats these as "link, don't host".
- **Proof anchor:** [Siftly Partners with Maruti Suzuki alongside Sarvam AI](https://siftly.ai/blog/siftly-maruti-suzuki-ai-search-visibility) — permission: true, linked, not restated.

## Agents fired — every node in the content graph ran

| # | Node | What it did | Guardrail verdict |
|---|---|---|---|
| c0 | intake_router | Validated inputs + set up run state | `intake_required_inputs` → **pass** |
| c1 | source_reconciler | Loaded 25 facts from brand ledger; flagged 1 conflict | seed_ledger 25 facts, 1 conflict |
| c2 | cannibalization / intent_guard | Set `page_intent = "generative engine optimization tools for the automotive industry"`, `primary_intent_type = commercial`, built intent_contract | cannibalization not-checked (no sitemap in account.yaml); intent_guard governed=True, 1000 head queries loaded from GSC export |
| c3 | kw_intent_mapper | Built keyword cluster (stub — no live Semrush key) | 1 term, real_volumes=False |
| c4 | serp_landscape | SERP feature targets computed | (implicit pass) |
| c5 | competitor_content | Gap entity matrix built | stub — no competitor pages fetched |
| c6 | brand_loader | Loaded `brand_voice` from brand_profile.json + 3 permissioned testimonials | testimonial_permissions usable=0/3 excluded (they're for other brands, not automobile) |
| c7 | strategist | Wrote `strategy` + `unique_insight` | grounding_check flagged 2 engines-count references → surfaces the ledger conflict |
| c8 | brief_compiler | Assembled landing-page brief with 6 structure blocks (value_prop, benefits, social_proof, how_it_works, cta, faq) | page_type=landing, 6 structure blocks |
| c9 | outline | Built section outline; enforced intent-boundary (link, don't host) against sibling `/use-cases/*` | entity_coverage unassigned=[], intent_boundary trespasses=[] |
| c10 | hook (lead) | 41-word answer-first intro | answer_first 41 words, flag_dont_fill [] |
| c11 | section_drafter | Wrote body sections | flag_dont_fill violations=[] |
| c12 | faq | 5 FAQ items | count 5 |
| c13 | evidence | Marked verify_list, no unresolved flags | evidence flags=0, resolved=0, unresolved=0 |
| c14 | eeat | Attached author (Chalam PVS) | eeat_from_brand_assets_only author=True |
| c15 | media | 1 media manifest item (SVG generated) | media items=1, ok=True |
| c16 | editorial | Cut unverified, dedupe repeats | no_new_facts ok=True, cut_unverified=0, dedupe_repeats=0 |
| c17 | a11y_perf | Accessibility + performance check | violations=[], ok=True |
| c18 | schema | Emitted JSON-LD (WebPage + FAQPage + Person) | approved_reviews=0 |
| c19 | **critic (L6)** | **BLOCKED** — 10 failures, info-gain score 26<70 | verdict=**fail**, failures=10 |
| c20 | render_critic | 4 render nits, verdict pass | render_critic verdict=pass |
| c21 | comparison_judge | Ran comparison judge | (implicit) |

**Route-back loop:** c19 failed → the graph looped back to L3 (`c10..c21`) twice more. Both re-drafts hit the same failures because the scripted-fake LLM is hard-coded to repeat them. After route_back cap (2) was hit, the run **escalated to human** as designed — this is exactly the behavior BUILD-SPEC §Guardrails pins.

## Why c19 blocked (this is the point of the demo)

The scripted-fake drafter wrote:

> Siftly monitors your brand across **4 AI engines** (fact:engines-count) …

But the brand ledger (loaded in c1 from `brand_profile.json`) says **9 engines** (ChatGPT, Gemini, Claude, Perplexity, Google AI Overviews, Google AI Mode, Copilot, AI Shopping, Groq). The critic caught:

1. **Fact conflict (blocker)** — `engines-count` referenced with 4, ledger locked at 9
2. **Vocabulary mirror 17% < 60% (blocker)** — copy doesn't use the commercial buyer's own head queries (would fail on a real automobile draft that ignored the auto long-tails you supplied)
3. **Info-gain 26 < 70 (major)** — page too thin; 0 external citations (target 3), 0 distinct data points (target 5)
4. **Unbacked quantifier "first"** — flagged for grounding

Every one of these is what a real production run would flag — the fake LLM just guarantees they show up so we can see the mechanism working end-to-end.

## For a real production run

Replace `--fake` with real credentials:

```bash
export AZURE_OPENAI_ENDPOINT="…"; export AZURE_OPENAI_API_KEY="…"
# (or) set provider: claude_code in config.yaml + have `claude` on PATH
python run.py content --mode net_new \
  --account siftly.ai \
  --inputs brands/siftly.ai/inputs/inputs-usecase-automobile.json \
  --out brands/siftly.ai/runs/prod-automobile
```

The same 22 agents will fire; a real drafter (Claude Sonnet 4.6 for strong, Haiku 4.5 for fast — per `config.yaml`) will honour the 9-engines fact, pull in the automotive keywords from `inputs.research_dossier`, and link out to the Maruti Suzuki post from `brand_assets.proof_anchors` — so c19 should pass on the first or second pass.

## Files in this run folder

- `runlog.md` — per-node duration, cost, guardrail verdicts (verbatim from the pipeline)
- `state.json` — full end-state (facts_ledger, brief, outline, sections, faq, draft, critic_report, render_report, comparison_report, schema_jsonld, media_manifest, intent_contract)
- `ledger.json` — the 25-fact append-only ledger with the engines-count conflict recorded
- `package_out.md` — packager output (empty because the run escalated at cap before c22)
- `AGENT-TRACE-summary.md` — this file

## Inputs used

See `brands/siftly.ai/inputs/inputs-usecase-automobile.json` for the full input record — seed keyword, secondary keywords with volumes from the Siftly Keyword Target Master, cluster context, the Maruti Suzuki proof anchor, and page requirements (H1 direction, required sections, schema types, CTA).

Sources:
- [Siftly Partners with Maruti Suzuki alongside Sarvam AI (Siftly blog, 29 Jun 2026)](https://siftly.ai/blog/siftly-maruti-suzuki-ai-search-visibility)
- Siftly Keyword Target Master (uploaded XLSX) — sheets `generative-engine-optimization`, `ai-brand-monitoring`, `share-of-voice_broad`, `SiteStructure1`
