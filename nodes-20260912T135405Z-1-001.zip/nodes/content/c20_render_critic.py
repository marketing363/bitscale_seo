"""c20_render_critic (L6): pixel-level checks. Deterministic.

H1/meta/CTA length limits from config; named-entity integrity: when a verified
fact's value enumerates names (e.g. "4 (ChatGPT, Claude, Perplexity, Google AI
Overviews)") and the fact is cited in the draft, every enumerated name must
actually appear — a count without its members is how "4 engines" silently
becomes three names and a vibe.
"""
from __future__ import annotations

import re
from pathlib import Path

import yaml

from ledger import FactsLedger
from page_profiles import get_profile

_CFG = yaml.safe_load((Path(__file__).parents[2] / "config.yaml").read_text())
_LIMITS = _CFG["ui_limits"]
_SEO = _CFG.get("seo_char_limits") or {}


def _check_range(label: str, value: str, key: str, owner: str,
                 sev_min: str = "major", sev_max: str = "major") -> list[dict]:
    """Check `value` against seo_char_limits[key] = [min, max]. Deterministic."""
    bounds = _SEO.get(key)
    if not bounds or value is None:
        return []
    lo, hi = bounds
    n = len(value)
    out = []
    if lo is not None and n < lo:
        out.append({"description": f"{label} {n} chars < min {lo}",
                    "owning_step": owner, "severity": sev_min,
                    "evidence": value[:140],
                    "fix": f"Expand {label} to at least {lo} characters."})
    if hi is not None and n > hi:
        out.append({"description": f"{label} {n} chars > max {hi}",
                    "owning_step": owner, "severity": sev_max,
                    "evidence": value[:140],
                    "fix": f"Trim {label} to at most {hi} characters."})
    return out


def _extract_h1(draft: str) -> str:
    m = re.search(r"^#\s+(.+)$", draft, re.MULTILINE)
    return m.group(1).strip() if m else ""


def _extract_h2s(draft: str) -> list[str]:
    return [m.strip() for m in re.findall(r"^##\s+(.+)$", draft, re.MULTILINE)]


def _extract_h3s(draft: str) -> list[str]:
    return [m.strip() for m in re.findall(r"^###\s+(.+)$", draft, re.MULTILINE)]


def _extract_paragraphs(draft: str) -> list[str]:
    out = []
    for block in re.split(r"\n\s*\n", draft):
        b = block.strip()
        if b and not b.startswith("#") and not b.startswith("-") and not b.startswith("*"):
            out.append(b)
    return out


def run(state: dict) -> dict:
    brief = state.get("brief") or {}
    draft = state.get("draft", "")
    manifest = state.get("media_manifest") or []
    outline = state.get("outline") or {}
    faq = state.get("faq") or []
    lead = state.get("lead", "") or ""
    failures = []

    # ── Named-entity integrity FIRST — if a locked fact enumerates names and
    #    the fact is cited, every name must appear in the draft. This is a
    #    blocker and should surface at the top of the failures list.
    _led_early = FactsLedger(list(state.get("facts_ledger", [])))
    for f in _led_early.facts:
        if f.get("status") != "verified" or f"(fact:{f['id']})" not in draft:
            continue
        m = re.search(r"\(([^()]+,[^()]+)\)", f["value"])
        if not m:
            continue
        names = [n.strip() for n in m.group(1).split(",") if n.strip()]
        missing = [n for n in names if n.lower() not in draft.lower()]
        if missing:
            failures.append({"description": f"fact '{f['id']}' cited but enumerated names missing from copy: {missing}",
                             "owning_step": "c11_section_drafter", "severity": "blocker",
                             "evidence": f["value"],
                             "fix": "Name every member the locked fact enumerates."})

    # Legacy UI limits (kept for back-compat with existing tests)
    title = brief.get("title_direction") or ""
    if len(title) > _LIMITS["h1_chars"]:
        failures.append({"description": f"title direction {len(title)} chars > {_LIMITS['h1_chars']}",
                         "owning_step": "c8_brief_compiler", "severity": "major",
                         "evidence": title, "fix": "Shorten the title direction."})
    meta = brief.get("meta_direction") or ""
    if len(meta) > _LIMITS["meta_chars"]:
        failures.append({"description": f"meta direction {len(meta)} chars > {_LIMITS['meta_chars']}",
                         "owning_step": "c8_brief_compiler", "severity": "major",
                         "evidence": meta, "fix": "Shorten the meta direction."})
    cta = brief.get("cta") or ""
    if cta and len(cta.split()) > _LIMITS["cta_words"]:
        failures.append({"description": f"CTA '{cta}' > {_LIMITS['cta_words']} words",
                         "owning_step": "c8_brief_compiler", "severity": "major",
                         "evidence": cta, "fix": "Shorten the CTA."})

    # ── Extended SEO character-count checks (seo_char_limits) ────────────
    if title:
        failures.extend(_check_range("title tag", title, "title_tag", "c8_brief_compiler"))
    if meta:
        failures.extend(_check_range("meta description", meta, "meta_description", "c8_brief_compiler"))
    h1 = _extract_h1(draft) or brief.get("h1_direction") or ""
    if h1:
        failures.extend(_check_range("H1", h1, "h1", "c10_hook"))
    if lead:
        failures.extend(_check_range("hero subhead / lead", lead, "hero_subhead", "c10_hook"))
    paras = _extract_paragraphs(draft)
    if paras:
        failures.extend(_check_range("AIO answer block (1st paragraph)", paras[0],
                                     "aio_answer_block", "c10_hook"))
    for h2 in _extract_h2s(draft):
        failures.extend(_check_range(f"H2 '{h2[:40]}'", h2, "h2", "c9_outline"))
    for h3 in _extract_h3s(draft):
        failures.extend(_check_range(f"H3 '{h3[:40]}'", h3, "h3", "c9_outline"))
    for i, item in enumerate(faq, 1):
        q = (item.get("q") or "").strip()
        a = (item.get("a") or "").strip()
        if q:
            failures.extend(_check_range(f"FAQ q#{i}", q, "faq_question", "c12_faq"))
        if a:
            failures.extend(_check_range(f"FAQ a#{i}", a, "faq_answer", "c12_faq"))
    for i, p in enumerate(paras, 1):
        failures.extend(_check_range(f"paragraph #{i}", p, "paragraph", "c11_section_drafter"))
    target_url = state.get("target_url") or brief.get("target_url") or ""
    slug = target_url.rstrip("/").split("/")[-1] if target_url else ""
    if slug:
        failures.extend(_check_range("URL slug", slug, "url_slug", "c2_cannibalization"))
    for item in manifest:
        alt = (item.get("alt") or "").strip()
        if alt:
            failures.extend(_check_range(f"alt '{item.get('filename','?')}'",
                                         alt, "image_alt", "c15_media"))

    # (named-entity integrity now runs at the top of run() so it stays failures[0])

    # manifest honored: every manifest image referenced or placed in a known section
    section_ids = {s.get("id") for s in (state.get("outline") or {}).get("sections", [])}
    for item in manifest:
        placed = item.get("placement") in section_ids or item.get("filename", "") in draft
        if not placed and item.get("type") != "screenshot":
            failures.append({"description": f"manifest image '{item.get('filename')}' not placed in any known section",
                             "owning_step": "c15_media", "severity": "major",
                             "evidence": str(item.get("placement")),
                             "fix": "Assign the image to an existing section id."})

    # page-type structure contract: required blocks must reach the draft
    profile = get_profile(state.get("page_type"))
    for block in profile.missing_blocks(draft, state.get("outline")):
        failures.append({"description": f"{profile.page_type} page missing required block: {block.label}",
                         "owning_step": "c9_outline", "severity": "major",
                         "evidence": f"no cue for '{block.id}' in draft/outline",
                         "fix": f"Add a section covering '{block.label}'."})

    # media gate (G6): a visual page type with zero images FAILS. SVG diagrams
    # count; screenshots requested as [HUMAN] count; base64 never allowed.
    _NEEDS_MEDIA = {"feature", "comparison", "guide", "listicle", "blog-listicle"}
    if profile.page_type in _NEEDS_MEDIA and not manifest:
        failures.append({"description": f"{profile.page_type} page has zero visual assets",
                         "owning_step": "c15_media", "severity": "blocker",
                         "evidence": "empty media_manifest",
                         "fix": "Add at least one hosted SVG diagram or a [HUMAN] screenshot request."})
    for item in manifest:
        if str(item.get("filename", "")).startswith("data:"):
            failures.append({"description": f"base64 image in manifest: {str(item.get('filename'))[:40]}",
                             "owning_step": "c15_media", "severity": "blocker",
                             "evidence": "data: URI", "fix": "Serve images as files, never base64."})

    blockers = [x for x in failures if x["severity"] == "blocker"]
    return {"render_report": {"verdict": "fail" if blockers else "pass",
                              "page_type": profile.page_type,
                              "failures": failures},
            "_guardrails": [{"check": "render_critic",
                             "verdict": "fail" if blockers else "pass",
                             "failures": len(failures)}]}
