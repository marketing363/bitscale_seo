# Audit: why the agent produces thin pages — and the structural gap behind it

**Page audited:** `/features/ai-prompt-analytics` (run `20260624T182808Z`)
**Verdict:** Passes every built-in gate, yet reads thin. The thinness is **designed into the pipeline**, not a copywriting miss. The system is architecturally a *"restate the owner's claims in SEO structure"* engine, not an *"information gain"* engine — so it cannot clear Google's helpful-content / E-E-A-T bar no matter how good the prose model is.

---

## 1. The thinness, quantified

| Signal | This page | What Google-quality needs |
|---|---|---|
| Body words | 2,185 | fine on length — length isn't the problem |
| **External citations** | **0** | multiple authoritative sources |
| **Concrete examples** ("for example", "such as", walkthroughs) | **0** | several per major section |
| **Distinct data points / numbers** | 16 tokens, mostly the *same* repeated ("9 engines", "#9", "3.5x") | original/proprietary data |
| **Repetition** | "visibility across ai" ×11, the 9-engine list ×7, "ai prompt analytics" ×10 | progressive, non-repeating |
| **Self-reference** | "siftly" ×45, "visibility" ×53 | reader value > brand mentions |

Length without evidence, examples, or new information = padding. That is the classic thin-content fingerprint.

---

## 2. Root cause — six structural gaps in the agent

### Gap 1 — Data starvation: the research layer is stubbed by design
`c3_kw_intent_mapper`, `c4_serp_landscape`, `c5_competitor_content` all depend on a **Semrush API key**. With no key they return `{"stub": True}`: 1 keyword, `real_volumes: False`, and competitor pages are **never fetched** ("gap derived from result titles only"). The agent walks in blind to demand, the SERP, and what competitors actually say. It has nothing external to be *more complete than*.

### Gap 2 — The evidence node retrieves nothing
`c13_evidence` is a **no-op verifier**. It collects `[VERIFY]` flags and converts them to human to-dos — it has **no web-lookup/RAG tool wired**. So any claim needing a source either stays an unbacked owner assertion or becomes a hole. There is no path in the graph for a fact to enter from outside the owner's brief.

### Gap 3 — The Facts Ledger is a closed world
The ledger for this page is **28 facts, every one owner-sourced, zero external URLs**. The append-only "never fabricate" rule is correct for safety — but combined with Gaps 1–2 it hard-caps the page's ceiling at *exactly what the owner already said*. Depth, comparisons, third-party proof, and data all require facts the ledger is never allowed to acquire.

### Gap 4 — The section drafter is isolated, so length comes from repetition
`c11_section_drafter` prompt: *"You see ONLY your section."* Each section re-explains the same core idea (visibility across AI engines) because it can't see what the others already covered. That's why "visibility across ai" appears 11× and the engine list 7×. The architecture manufactures length by **restating**, not by **advancing an argument**. No narrative spine, no progressive disclosure, no cumulative depth.

### Gap 5 — The quality gates measure *safety and form*, not *information gain*
This is the deepest gap. The critics (`c19/c20/c21`) enforce: no AI-tell phrases, H1 carries the keyword, no unsourced numbers, schema present, required blocks present, query mirroring. **None of them measure depth, originality, example density, data richness, or "does the reader learn something new."** So a page can — and did — pass every gate while being thin. The encoded definition of "quality" is *necessary but not sufficient* for Google quality. The agent is optimized to **not be wrong**, not to **be valuable**.

### Gap 6 — No topical breadth
With a stubbed SERP and a single seed keyword (`terms: 1`), there's no keyword cluster, no real People-Also-Ask expansion, no entity-coverage map. The outline is built around the **owner's framing**, not the **full question space** a comprehensive page must cover. Google rewards topical completeness; the agent never discovers the topic's true surface area.

---

## 3. What this means

The pipeline is excellent at what it was built for: structurally correct, on-brand, safe, schema-rich pages that never fabricate. But "doesn't fabricate" + "no research intake" = "can only recombine the brief." Google's helpful-content system rewards **information gain** — material a reader can't get elsewhere. This architecture has **no node whose job is to add information that isn't already in the owner brief**, and **no gate that fails a page for lacking it**. That is the gap.

---

## 4. Fixes, in priority order

1. **Turn research on (fastest lift).** Set `SEMRUSH_API_KEY` so `c3/c4/c5` return real volumes, the live SERP, and **fetched** competitor pages — the gap matrix and outline immediately widen.
2. **Wire an evidence-retrieval tool into `c13`.** Give it web fetch / RAG so `[VERIFY]` flags resolve to **real cited sources** (studies, docs, third-party data) that enter the ledger with provenance. Converts holes into authority.
3. **Add an information-gain / original-data node.** Inject Siftly's *proprietary* data as first-class sourced facts — benchmark numbers, methodology, more customer results than the 3 testimonials. Original data is the strongest E-E-A-T signal and the one thing competitors can't copy.
4. **De-isolate the drafter.** Pass `c11` the full outline + already-drafted sections (a shared narrative spine), and add a dedupe pass in `c16_editorial`. Kills the repetition; length starts coming from substance.
5. **Add a depth gate to the critic.** New deterministic checks: min external-citation count, min distinct-data count, example-density floor, repetition ceiling (no 3-gram >3×), and a brand-self-reference ratio cap. Make a thin page **fail** the way an AI-tell page fails today.
6. **Expand breadth.** Feed real PAA + entity coverage from the live SERP into the outline so the page covers the whole topic, not just the brand's angle.

**Bottom line:** keep the safety architecture; add an *intake* path for outside information (1–3) and a *gate* that demands it (5). Without those two, every page the agent makes will be safe, on-brand, and thin.
