# SEO character-limit audit — `/use-cases/automobile`

## Question you asked
> Are there certain SEO-optimised fields with min/max character counts the system checks? If not, add them and fix the page.

## Answer

**Partial before, complete now.** The pipeline's c20 render critic only checked title ≤ 60 chars, meta ≤ 155 chars, and CTA ≤ 5 words. Every other element in your table (H1, hero subhead, AIO answer block, H2, H3, FAQ q&a, paragraph, URL slug, image alt) had **no character-count guardrail**. I've added the full table as a first-class contract in `config.yaml`, extended `c20_render_critic.py` to enforce it, kept all 151 existing tests green, and cleaned up 9 violations on the automobile HTML.

## What was added

**`config.yaml` — new `seo_char_limits` map (source of truth):**

| Element | Min | Max |
|---|---:|---:|
| Title tag | 40 | 60 |
| Meta description | 120 | 160 |
| H1 | 20 | 70 |
| Hero subhead | 60 | 180 |
| AIO answer block | 200 | 400 |
| H2 headings | 20 | 70 |
| H3 subheads | 15 | 60 |
| FAQ question | 30 | 100 |
| FAQ answer | 100 | 300 |
| Paragraph | — | 600 |
| URL slug | — | 60 |
| Image alt | 30 | 125 |

**`nodes/content/c20_render_critic.py` — new deterministic checks:**
- `_check_range(label, value, key, owner)` reads bounds from `seo_char_limits` and emits `major` failures with a `fix:` hint
- Title, meta, H1 (from draft), hero subhead (`state.lead`), AIO answer block (first draft paragraph), every H2, every H3, every FAQ q/a, every paragraph, URL slug (from `state.target_url`), every image alt (from `media_manifest`)
- Named-entity integrity moved to the top of `run()` so it stays `failures[0]` — the existing enum-integrity test still passes

## Automobile page — audit before/after

**Before** (50 checks / 9 fails):

| # | Element | Was | Bound | Fix |
|---|---|---:|---|---|
| 1 | Meta description | 223 | ≤ 160 | Trimmed to 155 chars |
| 2 | Hero subhead (.lead) | 273 | ≤ 180 | Split into hero subhead (117) + AIO answer block (.lead-note, 316) |
| 3 | H2 "Related reading" | 15 | ≥ 20 | → "Related reading & guides" (24) |
| 4 | H3 "Local dealer and service prompts…" | 65 | ≤ 60 | → "Local dealer and service prompts are winnable today." (51) |
| 5 | H3 "Connect AI visibility to…" | 64 | ≤ 60 | → "Connect AI visibility to test-drive metrics." (44) |
| 6 | FAQ a#1 | 304 | ≤ 300 | Trimmed 4 chars (also updated JSON-LD) |
| 7 | FAQ a#2 | 323 | ≤ 300 | Dropped trailing summary sentence |
| 8 | FAQ a#4 | 361 | ≤ 300 | Compressed engine list |
| 9 | FAQ a#5 | 308 | ≤ 300 | Trimmed "not guessed" trailer |

**After:** ✅ 50/50 pass — `use-cases-automobile.html` is clean.

## Tests
- `pytest tests/` → **151 passed** (0 broken)
- The existing render-critic test (`test_render_critic_blocks_missing_enumerated_names`) still passes because named-entity integrity now runs before char-count checks.

## Files touched
- `config.yaml` — added `seo_char_limits`
- `nodes/content/c20_render_critic.py` — added `_check_range` + full element sweep
- `brands/siftly.ai/runs/20260704-usecase-automobile/use-cases-automobile.html` — 9 fixes to meta, hero, H2, H3s, FAQs (visible HTML + JSON-LD FAQPage kept in sync)
