# Operating model — running the agent so it ships Google-quality pages

The audit found the agent could ship safe-but-thin pages because it had a thin
goal, no hands, and a thin brain. This build adds all three. Here is how to run
it now.

## The four pillars, after this build

| Pillar | Before | Now |
|---|---|---|
| **GOAL** | gates checked form + safety only | + **information-gain gate** (`guardrails.information_gain`) scores every page 0–100 and can **fail** a thin one (`config quality_gates`) |
| **TOOLS** | Semrush stubbed, `c13` retrieved nothing | + **data-resolver** (Semrush → MCP → brain → **ask user**) and **web-fetch/RAG** wired into `c13` |
| **CONTEXT** | 28 owner facts in a JSON file | + **Brand Brain** SQLite store (facts w/ provenance, keywords, site structure, author, prefs, docs) editable in a **UI** |
| **SKILLS** | drafter saw only its own section → repetition | + drafter sees the **full outline**; `c16` runs a **dedupe** pass |

## One-time setup

```bash
pip install -r requirements.txt           # adds streamlit
# pick ONE way to give the model hands for drafting:
export AZURE_OPENAI_ENDPOINT="…/openai/responses?api-version=2025-04-01-preview"
export AZURE_OPENAI_API_KEY="…"
#   then set per-tier deployments in config.yaml -> azure_openai.deployments
#   (recommended: strong: gpt-5.5, fast: gpt-4o). Left blank in the repo so the
#   unit tests stay green — fill them in to run.
# give it research hands (optional but high-impact):
export SEMRUSH_API_KEY="…"                 # turns c3/c4/c5 from stub → real
```

> **Note on tests:** `config.yaml` ships with empty `deployments` so `pytest`
> stays 151/151 green. Filling them in is what makes a live run work; the two
> Azure tests assume the empty default.

## The run loop (per page)

1. **Fill the brain.** `streamlit run ui/app.py` → add the brand, author/E-E-A-T,
   keywords + target URLs, site structure, and paste brand docs. Mark any
   proprietary numbers as **original data** (that's the strongest E-E-A-T signal).
2. **Kick off the page** (`run.py content …`). As it runs, the **data-resolver**
   tries Semrush → MCP → brain for each data need. Anything no tool can supply
   becomes a **data request**.
3. **Answer the agent.** Open the UI → *Data requests* tab → fill in the missing
   data (with a source URL). Each answer becomes a sourced fact. This is the
   fallback that stops the agent shipping `[VERIFY]` holes.
4. **Re-run / resume.** `c13` now resolves `[VERIFY]` flags against the live web,
   and the **information-gain gate** scores the result. With
   `quality_gates.enforce_information_gain: true`, a page under 70 **fails** and
   routes back — the agent can no longer ship thin.
5. **Review + publish.** Check the *Info-gain* tab for the scorecard; resolve any
   remaining human checkpoints (screenshots, testimonial permissions); publish.

## How to turn the GOAL gate on

`config.yaml`:
```yaml
quality_gates:
  enforce_information_gain: true     # default false (advisory) → true (blocking)
```
Advisory mode (default) **scores** every page and surfaces the card without
changing pass/fail — good while you build the brain up. Flip to `true` once the
brain + tools can actually feed the page, so quality becomes mandatory.

## Practical sequence to get from "thin" to "passes"

The existing page scores **10/100**. To clear 70 you (and the tools) supply what
the metrics demand:

1. `SEMRUSH_API_KEY` → real volumes/SERP/PAA → entity breadth + real questions answered.
2. Brain: add 3+ **external** sources and 2+ **original** data points (your benchmarks).
3. The de-isolated drafter + dedupe pass kill the repetition (12× → ≤3) and lift value-sentence %.
4. Add 3+ concrete examples (the drafter prompt now asks for specifics).

Each of those maps 1:1 to a metric in `docs/GOAL-information-gain-metrics.md`.

## What still needs a human (by design)

Screenshots, customer-logo/testimonial permissions, author credentials/headshot,
and confirming legal/compliance claims. The agent flags these; it never invents
them. Resolve in the UI before publishing.
