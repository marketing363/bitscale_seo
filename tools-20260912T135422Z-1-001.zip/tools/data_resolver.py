"""Data-source resolver — the agent's "hands" with an honest fallback.

For every piece of data a page needs, try the configured sources **in order**:

    semrush  →  mcp  →  brain (DB)        (config: tools.data_resolver_order)

If a need is satisfied, return the value + provenance. If NO source can supply
it and `tools.on_missing == ask_user`, record a `data_request` in the brand
brain and mark the need `needs_user_input` so the run pauses for the user to
fill it in via the UI — instead of fabricating or shipping a thin `[VERIFY]`.

A "need" is a small dict:
    {"key": "kw_volume", "label": "Monthly search volume for 'ai prompt analytics'",
     "kind": "keyword", "term": "ai prompt analytics"}

Return:
    {
      "satisfied":  {key: {"value":..., "source":..., "source_url":...}},
      "missing":    [need, ...],          # could not be resolved anywhere
      "requested":  [request_id, ...],    # data_requests opened for the user
      "needs_user_input": bool,
      "report":     [{key, status, source}],   # audit trail
    }
"""
from __future__ import annotations

import os
from pathlib import Path

import yaml

from tools.brain import Brain


def _cfg() -> dict:
    return yaml.safe_load((Path(__file__).resolve().parents[1] / "config.yaml").read_text())


# ── provider availability + lookups ─────────────────────────────────────────
def _semrush_available() -> bool:
    return bool(os.environ.get("SEMRUSH_API_KEY"))


def _semrush_lookup(need: dict, domain: str):
    """Use the existing SemrushProvider for keyword needs. Returns dict or None."""
    if need.get("kind") != "keyword" or not need.get("term"):
        return None
    try:
        from tools.research import get_provider
        prov = get_provider()
        # exact per-term overview first, then fall back to related-keyword set
        row = prov.keyword_overview(need["term"])
        if not row:
            data = prov.research(need["term"])
            if not data or data.get("stub"):
                return None
            row = next((k for k in data.get("keywords", [])
                        if k.get("term", "").lower() == need["term"].lower()), None) \
                or (data.get("keywords") or [None])[0]
        if not row:
            return None
        if need["key"].endswith("volume") and row.get("volume") is not None:
            return {"value": row["volume"], "source": "semrush", "source_url": "semrush:analytics"}
        if need["key"].endswith("kd") and row.get("kd") is not None:
            return {"value": row["kd"], "source": "semrush", "source_url": "semrush:analytics"}
    except Exception:
        return None
    return None


def _mcp_available() -> bool:
    # An MCP data connector is considered available when explicitly enabled.
    # Wire a real client by registering a callable in MCP_PROVIDER (below).
    return bool(os.environ.get("MCP_DATA_AVAILABLE")) or MCP_PROVIDER is not None


MCP_PROVIDER = None  # set to a callable(need, domain) -> dict|None to enable MCP


def _mcp_lookup(need: dict, domain: str):
    if MCP_PROVIDER is None:
        return None
    try:
        return MCP_PROVIDER(need, domain)
    except Exception:
        return None


def _brain_lookup(need: dict, domain: str, brain: Brain):
    """Check the brand brain: keywords table for kw needs, facts for the rest."""
    if need.get("kind") == "keyword" and need.get("term"):
        for kw in brain.list_keywords(domain):
            if kw["term"].lower() == need["term"].lower():
                if need["key"].endswith("volume") and kw.get("volume") is not None:
                    return {"value": kw["volume"], "source": "brain", "source_url": "brain:keywords"}
                if need["key"].endswith("kd") and kw.get("kd") is not None:
                    return {"value": kw["kd"], "source": "brain", "source_url": "brain:keywords"}
    # generic: a fact whose id or claim matches the need key/label
    for f in brain.list_facts(domain):
        if need["key"] in (f["fact_id"] or "") or need["label"].lower() in (f["claim"] or "").lower():
            return {"value": f["value"] or f["claim"], "source": f["source_type"] or "brain",
                    "source_url": f["source_url"] or "brain:facts"}
    # already-answered data_request?
    for dr in brain.conn.execute(
            "SELECT * FROM data_requests WHERE domain=? AND need_key=? AND status='answered'",
            (domain, need["key"])):
        return {"value": dr["answer_text"], "source": "user", "source_url": dr["answer_source_url"] or ""}
    return None


_LOOKUPS = {"semrush": (_semrush_available, _semrush_lookup),
            "mcp": (_mcp_available, _mcp_lookup),
            "brain": (lambda: True, None)}  # brain handled specially (needs instance)


def resolve(domain: str, page_seed: str, needs: list[dict],
            brain: Brain | None = None, cfg: dict | None = None) -> dict:
    cfg = cfg or _cfg()
    tcfg = cfg.get("tools", {})
    order = tcfg.get("data_resolver_order", ["semrush", "mcp", "brain"])
    on_missing = tcfg.get("on_missing", "ask_user")
    brain = brain or Brain()

    satisfied, missing, requested, report = {}, [], [], []
    for need in needs:
        hit = None
        used = None
        for src in order:
            if src == "brain":
                hit = _brain_lookup(need, domain, brain)
            elif src == "semrush":
                hit = _semrush_lookup(need, domain) if _semrush_available() else None
            elif src == "mcp":
                hit = _mcp_lookup(need, domain) if _mcp_available() else None
            if hit:
                used = src
                break
        if hit:
            satisfied[need["key"]] = hit
            report.append({"key": need["key"], "status": "resolved", "source": used})
        else:
            missing.append(need)
            if on_missing == "ask_user":
                rid = brain.request_data(domain, page_seed, need["key"], need["label"])
                requested.append(rid)
                report.append({"key": need["key"], "status": "needs_user_input", "request_id": rid})
            elif on_missing == "fail":
                report.append({"key": need["key"], "status": "missing_fail"})
            else:  # stub
                report.append({"key": need["key"], "status": "stub"})

    return {"satisfied": satisfied, "missing": missing, "requested": requested,
            "needs_user_input": bool(requested) and on_missing == "ask_user",
            "report": report}


def gate_or_pause(domain: str, page_seed: str, needs: list[dict], brain: Brain | None = None) -> dict:
    """Convenience for nodes: resolve, and if anything needs user input, raise a
    structured signal the runner can surface (instead of shipping thin)."""
    res = resolve(domain, page_seed, needs, brain=brain)
    if res["needs_user_input"]:
        res["message"] = (f"{len(res['requested'])} data point(s) for '{page_seed}' have no "
                          f"source (no Semrush key / MCP / brain entry). Opened data_requests; "
                          f"answer them in the UI, then re-run.")
    return res
