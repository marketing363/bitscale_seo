"""Brand Brain UI (Streamlit) — manage a brand's context and answer the agent.

Run:
    pip install streamlit pyyaml
    streamlit run ui/app.py

Tabs:
  • Brand         — name, audience, author/E-E-A-T, preferences
  • Facts         — sourced facts (owner/docs/external/user), mark originals
  • Keywords      — term, intent, volume, KD, target URL, cluster
  • Site structure— pillar/spoke/leaf map for internal linking
  • Brand files   — paste/upload brand docs (feeds RAG + company brain)
  • Data requests — the agent's pending questions; answer them here (the fallback)
  • Info-gain     — view the latest run's information-gain scorecard
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tools.brain import Brain, seed_from_brand_profile  # noqa: E402

st.set_page_config(page_title="Brand Brain", layout="wide")
brain = Brain()

import os  # noqa: E402


# ── API keys (session only — kept in env, never written to disk) ─────────────
def _apply_env(key, val):
    if val:
        os.environ[key] = val


with st.sidebar.expander("🔑 API keys (session)", expanded=False):
    st.caption("Stored in this session's environment only — never saved to a file "
               "(the repo rule: keys live in env). Re-enter after a restart, or set "
               "them in your shell before `streamlit run`.")
    sem = st.text_input("SEMRUSH_API_KEY", type="password",
                        value=os.environ.get("SEMRUSH_API_KEY", ""))
    az_ep = st.text_input("AZURE_OPENAI_ENDPOINT", value=os.environ.get("AZURE_OPENAI_ENDPOINT", ""))
    az_key = st.text_input("AZURE_OPENAI_API_KEY", type="password",
                           value=os.environ.get("AZURE_OPENAI_API_KEY", ""))
    cda, cdb = st.columns(2)
    dep_s = cda.text_input("strong deployment", value="gpt-5.5")
    dep_f = cdb.text_input("fast deployment", value="gpt-4o")
    if st.button("Apply keys"):
        _apply_env("SEMRUSH_API_KEY", sem)
        _apply_env("AZURE_OPENAI_ENDPOINT", az_ep)
        _apply_env("AZURE_OPENAI_API_KEY", az_key)
        try:
            from tools.research import reset_provider
            reset_provider()
        except Exception:
            pass
        # write deployments into config.yaml (names aren't secrets)
        try:
            import re as _re
            cfgp = ROOT / "config.yaml"; txt = cfgp.read_text()
            txt = _re.sub(r'deployments: \{strong: "[^"]*", fast: "[^"]*"\}',
                          f'deployments: {{strong: "{dep_s}", fast: "{dep_f}"}}', txt)
            cfgp.write_text(txt)
        except Exception:
            pass
        st.success("Applied for this session.")
    # status row
    sem_on = bool(os.environ.get("SEMRUSH_API_KEY"))
    az_on = bool(os.environ.get("AZURE_OPENAI_API_KEY") and os.environ.get("AZURE_OPENAI_ENDPOINT"))
    st.write(f"Semrush: {'🟢 connected' if sem_on else '⚪ not set'}  ·  "
             f"Azure model: {'🟢 ready' if az_on else '⚪ not set'}")
    if sem_on and st.button("Test Semrush"):
        try:
            from tools.research import SemrushProvider
            ov = SemrushProvider().keyword_overview("seo")
            st.success(f"OK — 'seo' overview: {ov}") if ov else st.warning("Connected but no data returned.")
        except Exception as e:
            st.error(f"Semrush error: {e}")


# ── brand picker ────────────────────────────────────────────────────────────
st.sidebar.title("🧠 Brand Brain")
brands = brain.list_brands()
labels = [b["domain"] for b in brands]
choice = st.sidebar.selectbox("Brand", labels + ["➕ new brand…"]) if labels else "➕ new brand…"
if choice == "➕ new brand…":
    new_dom = st.sidebar.text_input("New brand domain (e.g. stitchmagic.in)")
    if st.sidebar.button("Create") and new_dom:
        brain.upsert_brand(new_dom.strip())
        st.rerun()
    domain = new_dom.strip() or (labels[0] if labels else "")
else:
    domain = choice

# seed-from-profile helper
with st.sidebar.expander("Seed from brands/<domain>/brand_profile.json"):
    seed_dom = st.text_input("domain to seed", value=domain or "")
    if st.button("Import profile") and seed_dom:
        pp = ROOT / "brands" / seed_dom / "brand_profile.json"
        ap = ROOT / "brands" / seed_dom / "account.yaml"
        if pp.exists():
            n = seed_from_brand_profile(brain, seed_dom, pp, ap if ap.exists() else None)
            st.success(f"seeded {n} facts for {seed_dom}")
            st.rerun()
        else:
            st.error(f"not found: {pp}")

if not domain:
    st.info("Create or select a brand to begin.")
    st.stop()

pending = brain.pending_requests(domain)
st.sidebar.metric("Pending data requests", len(pending))

tabs = st.tabs(["▶ Create Page", "Brand", "Facts", "Keywords", "Site structure", "Brand files",
                f"Data requests ({len(pending)})", "Info-gain"])
# index map (Create Page is first; the rest shift by 1)
T_CREATE, T_BRAND, T_FACTS, T_KW, T_SITE, T_FILES, T_REQ, T_IG = range(8)

# ── Create Page (run the pipeline) ───────────────────────────────────────────
with tabs[T_CREATE]:
    import subprocess
    import re as _re
    st.subheader(f"Create a page for {domain}")
    st.caption("Fill this in and click Generate. The agent researches, drafts, "
               "self-critiques, and scores the page for information gain.")
    try:
        import yaml as _yaml
        _cfg = _yaml.safe_load((ROOT / "config.yaml").read_text())
        page_types = list((_cfg.get("word_budget") or {"feature": 1}).keys())
        enforce = (_cfg.get("quality_gates") or {}).get("enforce_information_gain", False)
    except Exception:
        page_types, enforce = ["feature", "guide", "comparison", "landing"], False
    st.info(f"Information-gain gate is **{'ENFORCED (thin pages fail)' if enforce else 'advisory'}**.")

    seed = st.text_input("Seed keyword / topic", placeholder="ai prompt analytics")
    c1, c2 = st.columns(2)
    page_type = c1.selectbox("Page type", page_types)
    target_url = c2.text_input("Target URL", placeholder="/features/ai-prompt-analytics")
    context = st.text_area("Business context (what this page/product is)", height=90)
    c3, c4 = st.columns(2)
    cta = c3.text_input("Primary CTA", value="Book a demo")
    gsc = c4.text_input("GSC export path (optional .zip/.csv)", value="")

    if st.button("🚀 Generate page", type="primary"):
        if not seed:
            st.error("Enter a seed keyword.")
        else:
            slug = _re.sub(r"[^a-z0-9]+", "-", seed.lower()).strip("-")
            inputs = {"seed_keyword": seed, "page_type": page_type,
                      "business_context": context,
                      "research_dossier": {"primary_cta": cta, "target_url": target_url}}
            idir = ROOT / "brands" / domain / "inputs"; idir.mkdir(parents=True, exist_ok=True)
            ipath = idir / f"{slug}.json"
            ipath.write_text(json.dumps(inputs, indent=2))
            cmd = [sys.executable, "run.py", "content", "--mode", "net_new",
                   "--account", domain, "--inputs", str(ipath)]
            if gsc.strip():
                cmd += ["--gsc", gsc.strip()]
            st.code(" ".join(cmd), language="bash")
            with st.spinner("Running the pipeline (research → draft → critique → score)…"):
                proc = subprocess.run(cmd, cwd=str(ROOT), capture_output=True, text=True)
            st.text(proc.stdout[-1500:] or "(no stdout)")
            if proc.returncode != 0:
                st.error("Run did not complete cleanly:")
                st.text(proc.stderr[-1500:])
                if "deployment" in (proc.stderr + proc.stdout).lower():
                    st.warning("Set config.yaml → azure_openai.deployments (e.g. strong: gpt-5.5, "
                               "fast: gpt-4o) and export AZURE_OPENAI_ENDPOINT / AZURE_OPENAI_API_KEY.")
            # show newest run + its info-gain score regardless
            runs = sorted((ROOT / "brands" / domain / "runs").glob("*/state.json"))
            if runs:
                latest = runs[-1]
                try:
                    cr = (json.loads(latest.read_text()).get("critic_report") or {})
                    ig = cr.get("information_gain") or {}
                    if ig:
                        st.metric("Information-Gain score", f"{ig.get('score')} / 100",
                                  delta=("PASS" if ig.get("passes") else "THIN"),
                                  delta_color=("normal" if ig.get("passes") else "inverse"))
                    pkg = latest.parent / "package_out.md"
                    if pkg.exists():
                        st.download_button("Download package_out.md", pkg.read_text(),
                                           file_name="package_out.md")
                        with st.expander("Preview package_out.md"):
                            st.markdown(pkg.read_text()[:8000])
                except Exception as e:
                    st.write("run finished; couldn't parse scorecard:", e)
    st.divider()
    st.caption("After generating: open the **Data requests** tab to answer anything the agent "
               "couldn't source, then click Generate again to let the score climb.")


# ── Brand ───────────────────────────────────────────────────────────────────
with tabs[T_BRAND]:
    b = brain.get_brand(domain) or {}
    st.subheader(f"Brand · {domain}")
    c1, c2 = st.columns(2)
    name = c1.text_input("Name", b.get("name") or "")
    audience = c2.text_input("Audience", b.get("audience") or "")
    st.markdown("**Author (E-E-A-T)**")
    a1, a2 = st.columns(2)
    an = a1.text_input("Author name", b.get("author_name") or "")
    at = a2.text_input("Author title", b.get("author_title") or "")
    ac = st.text_input("Author credentials", b.get("author_credentials") or "")
    ab = st.text_area("Author bio", b.get("author_bio") or "", height=80)
    al = st.text_input("Author LinkedIn URL", b.get("author_linkedin") or "")
    st.markdown("**Preferences** (tone, words-to-avoid, CTA, etc. — JSON)")
    prefs = st.text_area("preferences (JSON)", json.dumps(b.get("preferences") or {}, indent=2), height=120)
    if st.button("💾 Save brand"):
        try:
            prefs_obj = json.loads(prefs or "{}")
        except Exception as e:
            st.error(f"preferences not valid JSON: {e}"); prefs_obj = b.get("preferences") or {}
        brain.upsert_brand(domain, name=name, audience=audience, author_name=an,
                           author_title=at, author_credentials=ac, author_bio=ab,
                           author_linkedin=al, preferences=prefs_obj)
        st.success("saved"); st.rerun()

# ── Facts ───────────────────────────────────────────────────────────────────
with tabs[T_FACTS]:
    st.subheader("Facts (with provenance)")
    facts = brain.list_facts(domain)
    if facts:
        st.dataframe([{"id": f["fact_id"], "claim": f["claim"], "value": f["value"],
                       "source": f["source_type"], "original": bool(f["is_original"]),
                       "url": f["source_url"]} for f in facts], use_container_width=True)
    with st.form("add_fact", clear_on_submit=True):
        st.markdown("**Add a fact**")
        fc1, fc2 = st.columns(2)
        fid = fc1.text_input("fact id (slug)")
        fval = fc2.text_input("value (optional, e.g. '9', '3.5x')")
        claim = st.text_input("claim")
        s1, s2, s3 = st.columns(3)
        stype = s1.selectbox("source", ["owner", "docs", "external", "user", "feature_page"])
        surl = s2.text_input("source URL")
        orig = s3.checkbox("original/proprietary data (E-E-A-T gold)")
        if st.form_submit_button("Add fact") and fid and claim:
            brain.add_fact(domain, fid, claim, value=fval, source_type=stype,
                           source_url=surl, is_original=orig)
            st.success("added"); st.rerun()

# ── Keywords ────────────────────────────────────────────────────────────────
with tabs[T_KW]:
    st.subheader("Keywords / site keyword structure")

    # ── Import a keyword CSV (no API needed) ─────────────────────────────────
    with st.container():
        st.markdown("**Import a keyword export (CSV)** — Semrush, Ahrefs, or GSC. "
                    "No API plan required; pull the export whenever you need and drop it here.")
        kcsv = st.file_uploader("Keyword CSV", type=["csv"], key="kw_csv")
        if kcsv is not None and st.button("⬆ Import CSV into brain"):
            try:
                from tools.keyword_import import import_keywords_csv
                text = kcsv.read().decode("utf-8", "ignore")
                res = import_keywords_csv(brain, domain, csv_text=text)
                if res.get("error"):
                    st.error(f"{res['error']} — headers seen: {res.get('headers')}")
                else:
                    st.success(f"Imported {res['imported']} keywords "
                               f"({res['questions']} questions). Columns: {res['columns_detected']}")
                    st.rerun()
            except Exception as e:
                st.error(f"Import failed: {e}")
    st.divider()

    # ── Pull from Semrush API (only if your plan has API access) ─────────────
    with st.container():
        sem_on = bool(os.environ.get("SEMRUSH_API_KEY"))
        cpa, cpb = st.columns([3, 1])
        seed_kw = cpa.text_input("Seed term to pull from Semrush",
                                 placeholder="ai prompt analytics", key="sem_seed")
        if cpb.button("⬇ Pull from Semrush", disabled=not sem_on):
            if not seed_kw:
                st.warning("Enter a seed term.")
            else:
                try:
                    from tools.research import SemrushProvider
                    prov = SemrushProvider()
                    data = prov.research(seed_kw)
                    if data.get("stub"):
                        st.warning("No key / stubbed — set SEMRUSH_API_KEY in 🔑 settings.")
                    else:
                        ov = prov.keyword_overview(seed_kw)
                        if ov:
                            brain.add_keyword(domain, ov["term"], volume=ov.get("volume"),
                                              kd=ov.get("kd"), source="semrush")
                        for k in data.get("keywords", [])[:30]:
                            if k.get("term"):
                                brain.add_keyword(domain, k["term"], volume=k.get("volume"),
                                                  kd=k.get("kd"), source="semrush")
                        for q in data.get("questions", [])[:20]:
                            brain.add_keyword(domain, q, intent_type="informational", source="semrush")
                        for c in data.get("organic", [])[:10]:
                            if c.get("url"):
                                brain.add_evidence(domain, f"competitor for '{seed_kw}'",
                                                   c["url"], c.get("domain", ""), "ranking competitor (Semrush)")
                        st.success(f"Pulled {len(data.get('keywords', []))} keywords, "
                                   f"{len(data.get('questions', []))} questions, "
                                   f"{len(data.get('organic', []))} competitors into the brain.")
                        st.rerun()
                except Exception as e:
                    st.error(f"Semrush pull failed: {e}")
        if not sem_on:
            st.caption("🔒 Add SEMRUSH_API_KEY in the sidebar (🔑 API keys) to enable live pulls.")
    st.divider()

    kws = brain.list_keywords(domain)
    if kws:
        st.dataframe([{"term": k["term"], "intent": k["intent_type"], "volume": k["volume"],
                       "KD": k["kd"], "target": k["page_url"], "cluster": k["cluster"]}
                      for k in kws], use_container_width=True)
    with st.form("add_kw", clear_on_submit=True):
        k1, k2, k3 = st.columns(3)
        term = k1.text_input("term")
        intent = k2.selectbox("intent", ["", "informational", "commercial", "transactional", "navigational"])
        vol = k3.number_input("volume", min_value=0, step=10, value=0)
        k4, k5, k6 = st.columns(3)
        kd = k4.number_input("KD", min_value=0.0, max_value=100.0, step=1.0, value=0.0)
        url = k5.text_input("target URL")
        cluster = k6.text_input("cluster")
        if st.form_submit_button("Add keyword") and term:
            brain.add_keyword(domain, term, intent_type=intent, volume=int(vol) or None,
                              kd=kd or None, page_url=url, cluster=cluster)
            st.success("added"); st.rerun()

# ── Site structure ──────────────────────────────────────────────────────────
with tabs[T_SITE]:
    st.subheader("Site structure (pillar / spoke / leaf — for internal linking)")
    pages = brain.list_pages(domain)
    if pages:
        st.dataframe([{"url": p["url"], "type": p["page_type"], "title": p["title"],
                       "parent": p["parent_url"], "role": p["role"]} for p in pages],
                     use_container_width=True)
    with st.form("add_page", clear_on_submit=True):
        p1, p2 = st.columns(2)
        url = p1.text_input("URL (e.g. /features/ai-prompt-analytics)")
        ptype = p2.text_input("page_type (feature/guide/comparison…)")
        p3, p4, p5 = st.columns(3)
        title = p3.text_input("title")
        parent = p4.text_input("parent URL")
        role = p5.selectbox("role", ["leaf", "spoke", "pillar"])
        if st.form_submit_button("Add page") and url:
            brain.add_page(domain, url, page_type=ptype, title=title, parent_url=parent, role=role)
            st.success("added"); st.rerun()

# ── Brand files ─────────────────────────────────────────────────────────────
with tabs[T_FILES]:
    st.subheader("Brand files (docs feed the company brain + RAG)")
    for f in brain.list_files(domain):
        st.write(f"📄 {f['filename']} · {f['kind']} · {f['chars']} chars")
    up = st.file_uploader("Upload a brand doc (txt/md)", type=["txt", "md"])
    if up is not None:
        content = up.read().decode("utf-8", "ignore")
        brain.add_file(domain, up.name, kind="upload", content_text=content)
        st.success(f"stored {up.name}"); st.rerun()
    with st.form("paste_doc", clear_on_submit=True):
        fn = st.text_input("name", "notes.md")
        txt = st.text_area("or paste brand content", height=140)
        if st.form_submit_button("Save text") and txt.strip():
            brain.add_file(domain, fn, kind="paste", content_text=txt)
            st.success("saved"); st.rerun()

# ── Data requests (the fallback) ────────────────────────────────────────────
with tabs[T_REQ]:
    st.subheader("Agent's pending data requests")
    st.caption("When no tool (Semrush / MCP / brain) can supply a data point, the "
               "agent opens a request here and pauses. Answer it, then re-run the page.")
    if not pending:
        st.success("No pending requests — the agent has everything it asked for.")
    for r in pending:
        with st.form(f"req_{r['id']}", clear_on_submit=True):
            st.markdown(f"**{r['need_label']}**  \n`{r['need_key']}` · page seed: *{r['page_seed']}*")
            ans = st.text_input("Your answer / data", key=f"a_{r['id']}")
            src = st.text_input("Source URL (optional)", key=f"s_{r['id']}")
            cols = st.columns(2)
            if cols[0].form_submit_button("✅ Answer"):
                if ans.strip():
                    brain.answer_request(r["id"], ans.strip(), src.strip())
                    st.success("answered → stored as a sourced fact"); st.rerun()
            if cols[1].form_submit_button("⏭ Skip"):
                brain.conn.execute("UPDATE data_requests SET status='skipped' WHERE id=?", (r["id"],))
                brain.conn.commit(); st.rerun()

# ── Info-gain scorecard ─────────────────────────────────────────────────────
with tabs[T_IG]:
    st.subheader("Latest information-gain scorecard")
    runs = sorted((ROOT / "brands" / domain / "runs").glob("*/package_out.json")) \
        if (ROOT / "brands" / domain / "runs").exists() else []
    pkgs = sorted((ROOT / "brands" / domain / "runs").glob("*/state.json")) if runs else []
    card = None
    for sj in reversed(pkgs):
        try:
            cr = (json.loads(sj.read_text()).get("critic_report") or {})
            if cr.get("information_gain"):
                card = cr["information_gain"]; st.caption(f"from {sj.parent.name}"); break
        except Exception:
            continue
    if not card:
        st.info("No scored run yet. Run a page, then refresh.")
    else:
        st.metric("Information-Gain score", f"{card['score']} / 100",
                  delta="PASS" if card["passes"] else "THIN",
                  delta_color="normal" if card["passes"] else "inverse")
        st.dataframe([{"metric": m["name"], "value": m["value"], "target": m["target"],
                       "ok": "✅" if m["ok"] else "❌", "weight": m["weight"]}
                      for m in card["metrics"]], use_container_width=True)
