# GOAL spec — the measurable value of a page that earns Google traffic

A page earns traffic when Google's helpful-content / E-E-A-T systems recognize **information gain**: material a reader can't easily get elsewhere. "Quality" must be a *number the agent can be graded against*, not a vibe. Below is the target the new GOAL gate enforces. Thresholds are for a ~1,500-word feature page; they scale with `word_budget` per page type.

## The composite: Information-Gain Score (0–100) — pass ≥ 70

Weighted sum of the checks below. The critic computes it every run and the page **fails** (blocker) when `enforce_information_gain: true`.

| # | Metric | Why Google rewards it | Pass threshold | Weight |
|---|---|---|---|---|
| 1 | **External authoritative citations** (distinct non-owner domains) | Corroboration = trust (E-E-A-T "Trust") | ≥ 3 distinct domains | 18 |
| 2 | **Distinct sourced data points / statistics** | Specificity signals first-hand knowledge | ≥ 5 | 16 |
| 3 | **Original / proprietary data** (owner's own benchmarks, study, methodology — sourced) | The #1 information-gain signal; uncopyable | ≥ 2 | 16 |
| 4 | **Concrete examples / walkthroughs / scenarios** | Demonstrates real experience ("Experience") | ≥ 3 | 12 |
| 5 | **Entity coverage** vs the topic's real entity set (from live SERP) | Topical completeness | ≥ 80% | 10 |
| 6 | **Real question coverage** (answers actual PAA questions) | Matches search intent surface | ≥ 5 questions | 8 |
| 7 | **Repetition ceiling** | Padding = thin-content flag | no 3-gram > 3×; keyword density ≤ 2.5% | 8 |
| 8 | **Brand self-reference ratio** | Reader value > self-promotion | ≤ 1 brand mention / 120 words | 6 |
| 9 | **Author E-E-A-T completeness** | "Expertise/Authoritativeness" | named author + credentials + bio + link | 6 |

## Hard pre-conditions (independent of the score — any miss = blocker)

- **Distinct value density:** ≥ 60% of sentences carry a fact, data point, example, or comparison (not a restatement).
- **Unique title + meta**, single keyword-bearing H1, valid schema (already enforced).
- **Freshness:** `dateModified` present **and** ≥ 1 *current* trend signal that is sourced (not `[VERIFY]`).
- **Zero unresolved `[VERIFY]` in shipped copy** (they either resolve via the RAG tool or the claim is cut).

## What this does NOT measure (and why traffic also needs it)

The page gate governs *content value*. Two things sit outside the page and must be handled by the operating model:

- **Targeting** — pick queries with real demand and winnable difficulty (needs Semrush/live SERP: volume + KD). A perfect page on a zero-demand term gets zero traffic.
- **Discoverability** — fast indexing: XML sitemap entry, internal links from existing authority pages, clean crawl path / `llms.txt`. "Immediate" traffic depends on this as much as on the copy.

## How the score changes behaviour

Today the critic fails a page for *form* problems (no keyword in H1, AI-tells, unsourced numbers). After this spec, it **also fails a page that scores < 70 on information gain** — which means the agent can no longer ship a safe-but-thin page. To *raise* the score it must pull in citations, data, and examples — which is exactly what the new Tools (RAG + Semrush + brand brain) and the user-data fallback are there to supply.
