"""Brand Brain (CONTEXT) — a per-brand SQLite store with provenance.

This is the agent's company brain: facts (with sources), keywords + the live
site structure, the author/E-E-A-T block, brand preferences, uploaded brand
documents (for RAG), retrieved evidence, and the queue of `data_requests` the
agent raises when it needs information no tool can supply.

Design rules that match the rest of the platform:
- Facts carry provenance (source_type + source_url). Nothing is anonymous.
- The store is additive; callers decide precedence (owner > docs > … ).
- Pure stdlib (sqlite3). No ORM, no external deps — the UI and the pipeline
  both import this module.

Typical use:
    from tools.brain import Brain
    b = Brain()                      # opens config brain.db_path
    b.upsert_brand("stitchmagic.in", name="StitchMagic", audience="Indian marketplace sellers")
    b.add_fact("stitchmagic.in", "pack-price", "Bulk Photo Pack is Rs 99 for 200 photos",
               value="9", source_type="owner")
    needs = b.resolve_or_request("stitchmagic.in", page_seed="meesho image size",
                                 needs=[("kw_volume","Search volume for the seed")])
"""
from __future__ import annotations

import json
import os
import sqlite3
import time
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS brands (
  domain TEXT PRIMARY KEY,
  name TEXT, audience TEXT,
  author_name TEXT, author_title TEXT, author_credentials TEXT,
  author_bio TEXT, author_linkedin TEXT,
  preferences_json TEXT DEFAULT '{}',
  created_at REAL
);
CREATE TABLE IF NOT EXISTS facts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  domain TEXT, fact_id TEXT, claim TEXT, value TEXT,
  source_type TEXT,          -- owner | docs | feature_page | external | user
  source_url TEXT, provenance TEXT,
  is_original INTEGER DEFAULT 0,   -- proprietary/owner data (E-E-A-T gold)
  locked INTEGER DEFAULT 0,
  added_at REAL,
  UNIQUE(domain, fact_id)
);
CREATE TABLE IF NOT EXISTS keywords (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  domain TEXT, term TEXT, intent_type TEXT,
  volume INTEGER, kd REAL, page_url TEXT, cluster TEXT, notes TEXT,
  source TEXT DEFAULT 'user',
  UNIQUE(domain, term)
);
CREATE TABLE IF NOT EXISTS site_structure (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  domain TEXT, url TEXT, page_type TEXT, title TEXT,
  parent_url TEXT, role TEXT,            -- pillar | spoke | leaf
  UNIQUE(domain, url)
);
CREATE TABLE IF NOT EXISTS brand_files (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  domain TEXT, filename TEXT, kind TEXT, path TEXT,
  content_text TEXT, added_at REAL
);
CREATE TABLE IF NOT EXISTS evidence (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  domain TEXT, query TEXT, source_url TEXT, source_domain TEXT,
  passage TEXT, retrieved_at REAL
);
CREATE TABLE IF NOT EXISTS data_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  domain TEXT, page_seed TEXT, need_key TEXT, need_label TEXT,
  status TEXT DEFAULT 'pending',         -- pending | answered | skipped
  answer_text TEXT, answer_source_url TEXT,
  created_at REAL, answered_at REAL,
  UNIQUE(domain, page_seed, need_key)
);
"""


def _cfg_db_path() -> str:
    try:
        import yaml
        cfg = yaml.safe_load((Path(__file__).resolve().parents[1] / "config.yaml").read_text())
        return (cfg.get("brain") or {}).get("db_path", "brand_brain.sqlite")
    except Exception:
        return "brand_brain.sqlite"


class Brain:
    def __init__(self, db_path: str | None = None):
        self.db_path = db_path or os.environ.get("BRAIN_DB") or _cfg_db_path()
        self.conn = sqlite3.connect(self.db_path)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    # ── brands ──────────────────────────────────────────────────────────────
    def upsert_brand(self, domain: str, **fields) -> None:
        cols = ["name", "audience", "author_name", "author_title", "author_credentials",
                "author_bio", "author_linkedin"]
        prefs = fields.pop("preferences", None)
        row = self.conn.execute("SELECT domain FROM brands WHERE domain=?", (domain,)).fetchone()
        if row is None:
            self.conn.execute("INSERT INTO brands(domain, created_at) VALUES(?,?)",
                              (domain, time.time()))
        for c in cols:
            if c in fields and fields[c] is not None:
                self.conn.execute(f"UPDATE brands SET {c}=? WHERE domain=?", (fields[c], domain))
        if prefs is not None:
            self.conn.execute("UPDATE brands SET preferences_json=? WHERE domain=?",
                              (json.dumps(prefs), domain))
        self.conn.commit()

    def get_brand(self, domain: str) -> dict | None:
        r = self.conn.execute("SELECT * FROM brands WHERE domain=?", (domain,)).fetchone()
        if not r:
            return None
        d = dict(r)
        d["preferences"] = json.loads(d.pop("preferences_json") or "{}")
        return d

    def list_brands(self) -> list[dict]:
        return [dict(r) for r in self.conn.execute("SELECT domain, name FROM brands ORDER BY domain")]

    # ── facts ───────────────────────────────────────────────────────────────
    def add_fact(self, domain, fact_id, claim, value="", source_type="owner",
                 source_url="", provenance="", is_original=False, locked=False):
        self.conn.execute(
            """INSERT INTO facts(domain,fact_id,claim,value,source_type,source_url,
               provenance,is_original,locked,added_at)
               VALUES(?,?,?,?,?,?,?,?,?,?)
               ON CONFLICT(domain,fact_id) DO UPDATE SET
                 claim=excluded.claim, value=excluded.value,
                 source_type=excluded.source_type, source_url=excluded.source_url,
                 provenance=excluded.provenance, is_original=excluded.is_original""",
            (domain, fact_id, claim, value, source_type, source_url, provenance,
             int(is_original), int(locked), time.time()))
        self.conn.commit()

    def list_facts(self, domain) -> list[dict]:
        return [dict(r) for r in self.conn.execute(
            "SELECT * FROM facts WHERE domain=? ORDER BY id", (domain,))]

    # ── keywords / site structure ───────────────────────────────────────────
    def add_keyword(self, domain, term, intent_type="", volume=None, kd=None,
                    page_url="", cluster="", notes="", source="user"):
        self.conn.execute(
            """INSERT INTO keywords(domain,term,intent_type,volume,kd,page_url,cluster,notes,source)
               VALUES(?,?,?,?,?,?,?,?,?)
               ON CONFLICT(domain,term) DO UPDATE SET
                 intent_type=excluded.intent_type, volume=excluded.volume, kd=excluded.kd,
                 page_url=excluded.page_url, cluster=excluded.cluster, notes=excluded.notes""",
            (domain, term, intent_type, volume, kd, page_url, cluster, notes, source))
        self.conn.commit()

    def list_keywords(self, domain) -> list[dict]:
        return [dict(r) for r in self.conn.execute(
            "SELECT * FROM keywords WHERE domain=? ORDER BY volume DESC NULLS LAST, term", (domain,))]

    def add_page(self, domain, url, page_type="", title="", parent_url="", role="leaf"):
        self.conn.execute(
            """INSERT INTO site_structure(domain,url,page_type,title,parent_url,role)
               VALUES(?,?,?,?,?,?)
               ON CONFLICT(domain,url) DO UPDATE SET
                 page_type=excluded.page_type, title=excluded.title,
                 parent_url=excluded.parent_url, role=excluded.role""",
            (domain, url, page_type, title, parent_url, role))
        self.conn.commit()

    def list_pages(self, domain) -> list[dict]:
        return [dict(r) for r in self.conn.execute(
            "SELECT * FROM site_structure WHERE domain=? ORDER BY url", (domain,))]

    # ── brand files / evidence ──────────────────────────────────────────────
    def add_file(self, domain, filename, kind="doc", path="", content_text=""):
        self.conn.execute(
            "INSERT INTO brand_files(domain,filename,kind,path,content_text,added_at) VALUES(?,?,?,?,?,?)",
            (domain, filename, kind, path, content_text, time.time()))
        self.conn.commit()

    def list_files(self, domain) -> list[dict]:
        return [dict(r) for r in self.conn.execute(
            "SELECT id,filename,kind,path,length(content_text) AS chars,added_at "
            "FROM brand_files WHERE domain=? ORDER BY id", (domain,))]

    def add_evidence(self, domain, query, source_url, source_domain, passage):
        self.conn.execute(
            "INSERT INTO evidence(domain,query,source_url,source_domain,passage,retrieved_at) VALUES(?,?,?,?,?,?)",
            (domain, query, source_url, source_domain, passage, time.time()))
        self.conn.commit()

    def list_evidence(self, domain) -> list[dict]:
        return [dict(r) for r in self.conn.execute(
            "SELECT * FROM evidence WHERE domain=? ORDER BY id DESC", (domain,))]

    # ── data_requests (the user-input fallback) ─────────────────────────────
    def request_data(self, domain, page_seed, need_key, need_label) -> int:
        self.conn.execute(
            """INSERT INTO data_requests(domain,page_seed,need_key,need_label,status,created_at)
               VALUES(?,?,?,?, 'pending', ?)
               ON CONFLICT(domain,page_seed,need_key) DO NOTHING""",
            (domain, page_seed, need_key, need_label, time.time()))
        self.conn.commit()
        r = self.conn.execute(
            "SELECT id FROM data_requests WHERE domain=? AND page_seed=? AND need_key=?",
            (domain, page_seed, need_key)).fetchone()
        return r["id"] if r else -1

    def pending_requests(self, domain=None, page_seed=None) -> list[dict]:
        q = "SELECT * FROM data_requests WHERE status='pending'"
        args = []
        if domain:
            q += " AND domain=?"; args.append(domain)
        if page_seed:
            q += " AND page_seed=?"; args.append(page_seed)
        return [dict(r) for r in self.conn.execute(q + " ORDER BY id", args)]

    def answer_request(self, req_id, answer_text, answer_source_url=""):
        self.conn.execute(
            "UPDATE data_requests SET status='answered', answer_text=?, answer_source_url=?, answered_at=? WHERE id=?",
            (answer_text, answer_source_url, time.time(), req_id))
        # an answered request also becomes a sourced fact
        r = self.conn.execute("SELECT * FROM data_requests WHERE id=?", (req_id,)).fetchone()
        if r:
            self.add_fact(r["domain"], f"user-{r['need_key']}", r["need_label"],
                          value=answer_text, source_type="user",
                          source_url=answer_source_url, provenance="user-supplied via UI")
        self.conn.commit()

    # ── export the brand as the pipeline's context dict ─────────────────────
    def brand_context(self, domain) -> dict:
        """Shape the brain into the dict the content pipeline already understands."""
        b = self.get_brand(domain) or {"domain": domain}
        return {
            "domain": domain,
            "audience": b.get("audience", ""),
            "brand_profile": {
                "facts": [{"id": f["fact_id"], "claim": f["claim"], "value": f["value"],
                           "source": f["source_type"], "source_url": f["source_url"],
                           "is_original": bool(f["is_original"])}
                          for f in self.list_facts(domain)],
                "author": {"name": b.get("author_name"), "title": b.get("author_title"),
                           "credentials": b.get("author_credentials"), "bio": b.get("author_bio"),
                           "linkedin": b.get("author_linkedin")},
                "preferences": b.get("preferences", {}),
            },
            "keywords": self.list_keywords(domain),
            "site_structure": self.list_pages(domain),
        }

    def close(self):
        self.conn.close()


# ── seeding helper ──────────────────────────────────────────────────────────
def seed_from_brand_profile(brain: "Brain", domain: str, profile_path: str | Path,
                            account_path: str | Path | None = None) -> int:
    """Import an existing brands/<domain>/brand_profile.json into the brain."""
    p = json.loads(Path(profile_path).read_text())
    audience = ""
    if account_path and Path(account_path).exists():
        import yaml
        audience = (yaml.safe_load(Path(account_path).read_text()) or {}).get("audience", "")
    brain.upsert_brand(domain, name=p.get("name") or domain, audience=audience)
    n = 0
    # features / value props / differentiators become facts
    for kind, key in [("feature", "features"), ("value_prop", "value_props"),
                      ("differentiator", "differentiators"), ("proof", "proof_points")]:
        for i, item in enumerate(p.get(key, []) or []):
            claim = item if isinstance(item, str) else json.dumps(item)
            brain.add_fact(domain, f"{kind}-{i}", claim[:240], source_type="owner",
                           is_original=(kind == "proof"))
            n += 1
    return n


if __name__ == "__main__":  # tiny smoke test / manual seed
    import sys
    b = Brain(sys.argv[1] if len(sys.argv) > 1 else None)
    print("brands:", b.list_brands())
