"""c11_section_drafter (L3): fan-out one drafting task per outline section.

Each task drafts ONE section but is now shown the FULL page outline (every other
section's heading + intent) so it knows the page's boundaries and does NOT
re-explain what a sibling section owns — the fix for the repetition/thinness the
audit found. flag_dont_fill runs on each body at exit; unsupported numbers
without a [VERIFY] flag are reported and enforced at c19.
"""
from __future__ import annotations

import json

from guardrails import flag_dont_fill
from ledger import FactsLedger
from llm import call_node


def run(state: dict) -> dict:
    led = FactsLedger(list(state.get("facts_ledger", [])))
    contract = state.get("intent_contract", {})
    must_mirror = [q["term"] for q in contract.get("head_queries", [])
                   if q.get("intent_type") in ("commercial", "transactional")]
    sections: dict[str, str] = {}
    covered: list[str] = []
    secs = list((state.get("outline") or {}).get("sections", []))
    led_md = led.to_markdown()
    voice = json.dumps(state.get("brand_voice", {}))
    mirror = json.dumps(must_mirror)
    # de-isolation: every drafter sees the whole page map (boundaries) so it
    # stops re-explaining the core concept that a sibling section owns.
    outline_map = json.dumps([
        {"id": s.get("id"), "h2": s.get("h2") or s.get("intent") or s.get("id")}
        for s in secs])

    def _draft(sec):
        res = call_node(
            "c11_section_drafter", "fast",
            section_spec=json.dumps(sec),
            brand_voice=voice,
            must_mirror=mirror,
            ledger_markdown=led_md,
            outline_map=outline_map,
            this_section_id=str(sec.get("id") or ""),
        )
        return sec, (res if isinstance(res, dict) else {})

    # Independent per-section calls — run concurrently (thread-safe: each call
    # builds its own httpx client). Order preserved to keep output deterministic.
    from concurrent.futures import ThreadPoolExecutor
    results = []
    if secs:
        with ThreadPoolExecutor(max_workers=min(8, len(secs))) as ex:
            results = list(ex.map(_draft, secs))
    for sec, res in results:
        sid = res.get("section_id") or sec.get("id")
        body = res.get("body_md") or res.get("body") or res.get("content") or res.get("markdown") or ""
        # Keep the heading with its body. The drafter returns h2 separately and the
        # assembler only ever joins bodies, so without this every page the pipeline
        # produces ships with no section headings at all - which fails the on-page
        # H2 check on every output and is invisible until you score the HTML.
        heading = (res.get("h2") or sec.get("h2") or "").strip()
        if heading and not body.lstrip().startswith("#"):
            body = f"## {heading}\n\n{body.lstrip()}"
        sections[sid] = body
        covered += res.get("entities_covered", []) if isinstance(res.get("entities_covered"), list) else []

    violations = []
    for body in sections.values():
        violations += flag_dont_fill(body, led)
    return {
        "sections": sections,
        "_guardrails": [{"check": "flag_dont_fill", "sections": len(sections),
                         "violations": [v.detail for v in violations]}],
    }
