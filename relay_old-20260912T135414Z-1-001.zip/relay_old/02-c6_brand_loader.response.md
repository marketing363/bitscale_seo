{
  "brand_voice": {
    "tone": "Plain, concrete, and on the seller's side. Names the problem in the seller's own terms before naming any feature. Concedes what a competing tool genuinely does better rather than claiming everything.",
    "person": "Second person to the seller ('you'), first person plural sparingly for the product. Never third-person corporate.",
    "sentence_rhythm": "Short declarative openers followed by a longer explanatory sentence. Varied length; no stacked equal-length sentences. Paragraphs of three to four sentences.",
    "words_to_use": ["listing", "catalog", "catalogue", "drop", "SKU", "QC", "rejected", "primary image", "portal", "spec", "resize", "KB limit", "phone", "rupees", "seller", "Meesho", "Flipkart", "Amazon", "Myntra", "WhatsApp"],
    "words_to_avoid": ["AI-powered", "revolutionary", "seamless", "effortless", "game-changing", "unlock", "supercharge", "subscription", "per month", "dollars", "$", "leverage", "solution"],
    "notes": "Hinglish is welcome where a seller would genuinely search in it. Currency is INR. Examples must be Indian marketplaces, never US ones."
  },
  "usable_assets": [
    {"type": "differentiator", "id": "exact-meesho-myntra-flipkart-and-amazon-", "value": "Exact Meesho, Myntra, Flipkart and Amazon sizes from one upload", "source": "brand_profile"},
    {"type": "differentiator", "id": "free-on-single-photos-no-signup-no-water", "value": "Free on single photos - no signup, no watermark, no daily limit", "source": "brand_profile"},
    {"type": "differentiator", "id": "photos-never-leave-the-device-everything", "value": "Photos never leave the device; everything runs in the browser", "source": "brand_profile"},
    {"type": "differentiator", "id": "fixes-the-things-that-actually-get-listi", "value": "Fixes the things that actually get listings rejected, in the right order", "source": "brand_profile"},
    {"type": "differentiator", "id": "one-photo-counts-once-however-many-steps", "value": "One photo counts once however many steps it passes through", "source": "brand_profile"},
    {"type": "differentiator", "id": "built-for-a-phone-because-that-is-what-t", "value": "Built for a phone, because that is what the seller has", "source": "brand_profile"},
    {"type": "feature", "id": "feat-free-kb-and-pixel-resizers", "value": "Resize or compress to an exact KB target, a pixel size, or a min-max range for portals that demand both bounds.", "source": "brand_profile"},
    {"type": "feature", "id": "feat-marketplace-image-tools", "value": "Meesho, Flipkart and Amazon listing images at the exact required specification, including QC-safe backgrounds.", "source": "brand_profile"},
    {"type": "feature", "id": "feat-bulk-photo-pack", "value": "Runs a whole drop through repair, four marketplace sizes, branding, format conversion, SKU renaming and a WhatsApp PDF in one pass.", "source": "brand_profile"},
    {"type": "feature", "id": "feat-whatsapp-catalogue", "value": "Turns a folder of product photos and prices into a shareable PDF catalogue.", "source": "brand_profile"},
    {"type": "proof_point", "id": "proof-processing-happens-in-the-browse", "value": "Processing happens in the browser via Canvas and WebGL - files are not uploaded", "source": "brand_profile"},
    {"type": "proof_point", "id": "proof-marketplace-hero-images-are-kept", "value": "Marketplace hero images are kept clean automatically, because Meesho rejects logos and badges on catalog images", "source": "brand_profile"},
    {"type": "proof_point", "id": "proof-one-off-99-pack-rather-than-a-su", "value": "One-off Rs 99 pack rather than a subscription", "source": "brand_profile"},
    {"type": "internal_link_targets", "value": ["/image-resizer", "/image-compressor", "/tools/meesho-image-resizer", "/marketplace/meesho-image-guide", "/compare/photoroom-alternative-for-sellers", "/tools/meesho-catalog-maker", "/catalog-maker", "/pricing"], "source": "brand_assets"},
    {"type": "og_image", "value": "https://res.cloudinary.com/domgrw24m/image/upload/v1766843202/stitchmagic-hero-fixed/njxhiffvsklszd9nquer.webp", "source": "brand_assets"},
    {"type": "logo", "value": "https://stitchmagic.in/android-chrome-192x192.png", "source": "brand_assets"}
  ],
  "unusable_assets": [
    {"type": "testimonial", "value": "[VERIFY: no testimonials supplied]", "reason": "No testimonials exist in the brand profile or canonical sources. None may be written, and none may be implied."},
    {"type": "author_bio", "value": "[VERIFY: no named author or credential supplied]", "reason": "No author identity, role or credential is available, so no byline or expertise claim can be made on the page."},
    {"type": "screenshot", "value": "[VERIFY: no product screenshots supplied]", "reason": "Only a logo and an OG image are in brand_assets. No UI screenshots are available to illustrate the comparison."},
    {"type": "competitor_pricing", "value": "[VERIFY: Canva plan names and prices not supplied]", "reason": "No canonical source for Canva's pricing. Plans and tiers change, so no price, tier name or free-plan limit may be stated for Canva on this page."},
    {"type": "competitor_feature_claims", "value": "[VERIFY: Canva feature set not supplied from a canonical source]", "reason": "canonical_page_texts is empty, so no specific Canva capability, limit or behaviour can be asserted as fact. The comparison must stay at the level of what a design tool is for versus what a listing-spec tool is for."}
  ],
  "human_checkpoints": [
    "brand_voice here is derived from the brand profile only: canonical_page_texts was empty, so no live page text informed the rhythm or vocabulary. Confirm it matches the published site before this ships.",
    "No testimonial, author identity or credential exists. The page will carry no EEAT authorship signal. If a named author or seller quote can be supplied with permission, this page is the place for it.",
    "Any statement about what Canva does, costs or limits needs a human to verify against Canva's own site at publication time. The draft must not assert one.",
    "The Rs 99 for 200 photos and Rs 299 for 1,000 pack terms come from the brand profile pricing_notes. Confirm they are still current before publishing.",
    "Confirm the page does not overlap /compare/photoroom-alternative-for-sellers, which owns background removal. This page owns the design-tool-versus-spec-tool question only."
  ]
}
