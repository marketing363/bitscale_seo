ROLE: Lead writer. One job: the answer-first opening.
INPUT: primary_keyword="canva alternative for product photos", unique_insight=Canva and a listing tool are not competing at the same job, and the seller only discovers this at QC. Canva is built to design something new - to add, arrange and decorate. A marketplace primary image is judged on the opposite: an existing photograph, at an exact pixel size and file size, with nothing added to it at all. Every instinct a design tool trains (put the shop name on it, add a festive frame, make a collage of the range) is a documented rejection reason (fact:proof-marketplace-hero-images-are-kept). So the seller who is best at Canva often gets rejected most, and the page that says this plainly owns a query no design-tool comparison currently answers., audience="Indian marketplace sellers who currently use Canva to prepare listing photos and keep getting catalogs rejected", brand_voice={"tone": "Plain, concrete, and on the seller's side. Names the problem in the seller's own terms before naming any feature. Concedes what a competing tool genuinely does better rather than claiming everything.", "person": "Second person to the seller ('you'), first person plural sparingly for the product. Never third-person corporate.", "sentence_rhythm": "Short declarative openers followed by a longer explanatory sentence. Varied length; no stacked equal-length sentences. Paragraphs of three to four sentences.", "words_to_use": ["listing", "catalog", "catalogue", "drop", "SKU", "QC", "rejected", "primary image", "portal", "spec", "resize", "KB limit", "phone", "rupees", "seller", "Meesho", "Flipkart", "Amazon", "Myntra", "WhatsApp"], "words_to_avoid": ["AI-powered", "revolutionary", "seamless", "effortless", "game-changing", "unlock", "supercharge", "subscription", "per month", "dollars", "$", "leverage", "solution"], "notes": "Hinglish is welcome where a seller would genuinely search in it. Currency is INR. Examples must be Indian marketplaces, never US ones."}
TASK: Write the lead: 40-60 words, answers the query in the first sentence, no throat-clearing, no rhetorical questions. Cite ledger facts inline (fact:id) for any number.
OUTPUT: JSON with keys lead (string), word_count.

RULES (non-negotiable):
- Assert only facts present in the FACTS LEDGER below or directly quoted from CANONICAL SOURCES.
- A missing fact must be written as [VERIFY: what is missing]. Never invent a number, source, feature, credential, quote, or URL.
- When citing a ledger fact inline, append its id like (fact:engines-count).
- Output ONLY the JSON object matching the schema given. No prose around it.
FACTS LEDGER:
| id | claim | value | status | source |
|---|---|---|---|---|
| exact-meesho-myntra-flipkart-and-amazon- | Value proposition | Exact Meesho, Myntra, Flipkart and Amazon sizes from one upload | verified | brand_profile |
| free-on-single-photos-no-signup-no-water | Value proposition | Free on single photos — no signup, no watermark, no daily limit | verified | brand_profile |
| photos-never-leave-the-device-everything | Value proposition | Photos never leave the device; everything runs in the browser | verified | brand_profile |
| fixes-the-things-that-actually-get-listi | Value proposition | Fixes the things that actually get listings rejected, in the right order | verified | brand_profile |
| one-photo-counts-once-however-many-steps | Value proposition | One photo counts once however many steps it passes through | verified | brand_profile |
| built-for-a-phone-because-that-is-what-t | Value proposition | Built for a phone, because that is what the seller has | verified | brand_profile |
| feat-free-kb-and-pixel-resizers | Feature: Free KB and pixel resizers | Resize or compress to an exact KB target, a pixel size, or a min-max range for portals that demand both bounds. | verified | brand_profile |
| feat-hd-photo-converter | Feature: HD photo converter | Upscale and sharpen a soft photo to 720p, 1080p, 1440p or 4K in the browser. | verified | brand_profile |
| feat-marketplace-image-tools | Feature: Marketplace image tools | Meesho, Flipkart and Amazon listing images at the exact required specification, including QC-safe backgrounds. | verified | brand_profile |
| feat-bulk-photo-pack | Feature: Bulk Photo Pack | Runs a whole drop through repair, four marketplace sizes, branding, format conversion, SKU renaming and a WhatsApp PDF in one pass. | verified | brand_profile |
| feat-whatsapp-catalogue | Feature: WhatsApp catalogue | Turns a folder of product photos and prices into a shareable PDF catalogue. | verified | brand_profile |
| feat-seller-calculators | Feature: Seller calculators | Commission, RTO, breakeven and shipping arithmetic for Meesho, Flipkart and Amazon. | verified | brand_profile |
| proof-single-photo-tools-are-genuinely | Proof point | Single-photo tools are genuinely free with no watermark and no signup | verified | brand_profile |
| proof-processing-happens-in-the-browse | Proof point | Processing happens in the browser via Canvas and WebGL — files are not uploaded | verified | brand_profile |
| proof-marketplace-hero-images-are-kept | Proof point | Marketplace hero images are kept clean automatically, because Meesho rejects logos and badges on catalog images | verified | brand_profile |
| proof-one-off-99-pack-rather-than-a-su | Proof point | One-off ₹99 pack rather than a subscription | verified | brand_profile |
