{
  "section_id": "answer",
  "h2": "The short answer",
  "body_md": "**Two different jobs.** Canva composes something new — you start with an empty frame and add to it. A marketplace primary image is the opposite: an existing photograph, taken to an exact pixel size and file size, with nothing added at all. Meesho rejects logos and badges on catalog images (fact:proof-marketplace-hero-images-are-kept), so the adding is what fails you. Stay on Canva for social posts and festive creatives.",
  "entities_covered": ["Canva", "primary image", "marketplace listing", "specification"],
  "verify_flags": []
}
