{
  "brief": {
    "title_direction": "Canva Alternative for Product Photos That Pass QC",
    "meta_direction": "Canva is built to design something new. A marketplace primary image is judged on the opposite. Which tool each job needs, and when Canva is right.",
    "structure": [
      {"id": "answer", "h2": "The short answer", "intent": "Answer-first verdict, quotable in isolation. State that these are two different jobs: Canva designs something new, a listing image takes an existing photo to an exact spec with nothing added. Name who should stay on Canva in the same breath. No hedging, no preamble."},
      {"id": "canva_wins", "h2": "What Canva is genuinely better at", "intent": "Concede first and concretely. Social posts, festive creatives, banners, price lists, anything where you are composing rather than conforming. A reader who does not find their own use case honestly described here stops trusting the rest of the page. Keep every statement at the level of what design tools are for as a category - no Canva feature, limit, plan or price may be asserted."},
      {"id": "two_jobs", "h2": "Designing something new is not the same job as meeting a spec", "intent": "The page's owned idea. A design tool trains you to add: put the shop name on it, add a frame, make a collage of the range. A primary catalog image is judged on having none of that (fact:proof-marketplace-hero-images-are-kept). So the seller who is most fluent in a design tool often gets rejected most, which is the counterintuitive line worth stating plainly."},
      {"id": "portal_rules", "h2": "The rules a design tool has no reason to know", "intent": "Concrete constraints: pixel dimensions and file size set independently, aspect ratio that fills the box rather than letterboxing, and a primary image carrying nothing but the product. Explain why each fails a catalog. Link to the full spec rather than reproducing numbers. Introduce the resizer and compressor as the direct answers (fact:feat-free-kb-and-pixel-resizers, fact:feat-marketplace-image-tools)."},
      {"id": "whole_drop", "h2": "One image, or forty", "intent": "Scale changes the tool. Designing forty listing images one at a time is an evening; a spec pipeline is one pass (fact:feat-bulk-photo-pack, fact:exact-meesho-myntra-flipkart-and-amazon-). Also where the WhatsApp catalogue belongs (fact:feat-whatsapp-catalogue). This is the section that earns the commercial bridge without becoming a pitch."},
      {"id": "objections", "h2": "Free, private, and not a subscription", "intent": "Answer the three objections a seller actually has, plainly and in her words: is it really free (fact:free-on-single-photos-no-signup-no-water), do my photos get uploaded (fact:proof-processing-happens-in-the-browse, fact:photos-never-leave-the-device-everything), am I signing up for a monthly charge (fact:proof-one-off-99-pack-rather-than-a-su, fact:one-photo-counts-once-however-many-steps). Link /pricing so the pack terms are checkable."},
      {"id": "decision", "h2": "Which to use, and when", "intent": "A decision rule the reader can apply the same evening. Two short lists - reach for a design tool when X, reach for a spec tool when Y - with Canva named as the right answer in roughly half the cases. Ends on the reader's judgement, not on our product."},
      {"id": "faq", "h2": "Frequently asked questions", "intent": "Six questions in the seller's own phrasing, each answerable standalone for AI citation. Must include: can I use Canva for Meesho listing images, why was my catalog rejected when the photo looked good, do I need both tools, does a watermark get a listing rejected, what size should a listing image be, is a design tool bad for e-commerce. No Canva-specific limit may be asserted in any answer."}
    ],
    "word_budgets": {"answer": 70, "canva_wins": 200, "two_jobs": 220, "portal_rules": 260, "whole_drop": 190, "objections": 180, "decision": 160, "faq": 320, "total": 1600},
    "media_plan": [
      {"placement": "after two_jobs", "type": "diagram", "spec": "Two-column figure contrasting the two jobs: left, a design canvas where elements are added to an empty frame; right, an existing photograph being constrained to a pixel box and a KB ceiling with nothing overlaid. Purpose-drawn SVG, no stock photography, captioned with the section's claim. Must be drawn for this page and used on no other."},
      {"placement": "inside portal_rules", "type": "diagram", "spec": "A primary image annotated with the four things that get it rejected - text, logo or watermark, border or frame, collage panel - each marked against a clean version that passes. Grounded in (fact:proof-marketplace-hero-images-are-kept). Numbers for any specific portal spec must be omitted here and linked instead."},
      {"placement": "inside decision", "type": "table", "spec": "Two-column decision table, design-tool job versus listing-spec job, five rows. Plain text table, no image, so it is readable to a crawler and on a phone."},
      {"placement": "optional, inside canva_wins", "type": "screenshot", "spec": "[HUMAN] A real seller's Canva social post beside her rejected listing image would make the concession concrete. No screenshots exist in brand_assets, so this is a human ask and the page must read complete without it."}
    ],
    "cta": "Try the free resizer",
    "internal_link_targets": [
      {"url": "/image-resizer", "section": "portal_rules", "anchor_intent": "resize a photo to a portal spec", "role": "primary CTA"},
      {"url": "/image-compressor", "section": "portal_rules", "anchor_intent": "get a photo under a KB limit"},
      {"url": "/marketplace/meesho-image-guide", "section": "portal_rules", "anchor_intent": "the Meesho image spec in full", "role": "scope fence - numbers live there, not here"},
      {"url": "/compare/photoroom-alternative-for-sellers", "section": "canva_wins", "anchor_intent": "background removal specifically", "role": "scope fence - that page owns background removal"},
      {"url": "/tools/meesho-image-resizer", "section": "portal_rules", "anchor_intent": "Meesho listing size"},
      {"url": "/tools/meesho-catalog-maker", "section": "whole_drop", "anchor_intent": "build a whole catalog"},
      {"url": "/catalog-maker", "section": "whole_drop", "anchor_intent": "turn a folder into a catalogue"},
      {"url": "/pricing", "section": "objections", "anchor_intent": "what the pack costs", "role": "makes the one-off claim checkable"}
    ]
  }
}
