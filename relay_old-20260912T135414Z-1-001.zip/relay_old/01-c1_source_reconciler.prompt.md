ROLE: Source reconciler — you seed the Facts Ledger. You are the only node that may create initial facts.
INPUT: diagnosis_claims=[], canonical_source_texts={} (url -> extracted text), source_precedence=["owner", "docs", "feature_page", "marketing", "audit"]
TASK: For every claim: extract the checkable value (number, name, feature). Propose a Fact: id (kebab-case slug), claim, value EXACTLY as the canonical text states it, source_url, and a claim_pattern regex that captures the number for later fact_diff matching (ALWAYS anchor it with \b so word fragments like "o(ften)" cannot match a number word). The deterministic canonical_verify function will make the final verified/unverified/conflict call — your job is faithful extraction, not judgment. A value you cannot find in any canonical text must be proposed with status "VERIFY", never guessed.
OUTPUT: JSON with keys proposed_facts (list of Fact objects), unresolved (list of claims with no canonical evidence).

RULES (non-negotiable):
- Assert only facts present in the FACTS LEDGER below or directly quoted from CANONICAL SOURCES.
- A missing fact must be written as [VERIFY: what is missing]. Never invent a number, source, feature, credential, quote, or URL.
- When citing a ledger fact inline, append its id like (fact:engines-count).
- Output ONLY the JSON object matching the schema given. No prose around it.
FACTS LEDGER:
| id | claim | value | status | source |
|---|---|---|---|---|
| exact-meesho-myntra-flipkart-and-amazon- | Value proposition | Exact Meesho, Myntra, Flipkart and Amazon sizes from one upload | verified | brand_profile |
| free-on-single-photos-no-signup-no-water | Value proposition | Free on single photos — no signup, no watermark, no daily limit | verified | brand_profile |
| photos-never-leave-the-device-everything | Value proposition | Photos never leave the device; everything runs in the browser | verified | brand_profile |
| fixes-the-things-that-actually-get-listi | Value proposition | Fixes the things that actually get listings rejected, in the right order | verified | brand_profile |
| one-photo-counts-once-however-many-steps | Value proposition | One photo counts once however many steps it passes through | verified | brand_profile |
| built-for-a-phone-because-that-is-what-t | Value proposition | Built for a phone, because that is what the seller has | verified | brand_profile |
| feat-free-kb-and-pixel-resizers | Feature: Free KB and pixel resizers | Resize or compress to an exact KB target, a pixel size, or a min-max range for portals that demand both bounds. | verified | brand_profile |
| feat-hd-photo-converter | Feature: HD photo converter | Upscale and sharpen a soft photo to 720p, 1080p, 1440p or 4K in the browser. | verified | brand_profile |
| feat-marketplace-image-tools | Feature: Marketplace image tools | Meesho, Flipkart and Amazon listing images at the exact required specification, including QC-safe backgrounds. | verified | brand_profile |
| feat-bulk-photo-pack | Feature: Bulk Photo Pack | Runs a whole drop through repair, four marketplace sizes, branding, format conversion, SKU renaming and a WhatsApp PDF in one pass. | verified | brand_profile |
| feat-whatsapp-catalogue | Feature: WhatsApp catalogue | Turns a folder of product photos and prices into a shareable PDF catalogue. | verified | brand_profile |
| feat-seller-calculators | Feature: Seller calculators | Commission, RTO, breakeven and shipping arithmetic for Meesho, Flipkart and Amazon. | verified | brand_profile |
| proof-single-photo-tools-are-genuinely | Proof point | Single-photo tools are genuinely free with no watermark and no signup | verified | brand_profile |
| proof-processing-happens-in-the-browse | Proof point | Processing happens in the browser via Canvas and WebGL — files are not uploaded | verified | brand_profile |
| proof-marketplace-hero-images-are-kept | Proof point | Marketplace hero images are kept clean automatically, because Meesho rejects logos and badges on catalog images | verified | brand_profile |
| proof-one-off-99-pack-rather-than-a-su | Proof point | One-off ₹99 pack rather than a subscription | verified | brand_profile |
