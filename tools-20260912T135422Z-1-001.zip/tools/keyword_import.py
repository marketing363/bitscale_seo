"""Import a Semrush (or Ahrefs/GSC) keyword export CSV into the brand brain.

No API needed — this is the offline path for plans without API access. Handles
the common export shapes: comma/semicolon/tab delimited, UTF-8 with or without a
BOM, and the usual column names from Semrush ("Keyword", "Search Volume",
"Keyword Difficulty", "Intent", "CPC", …), Ahrefs ("Keyword", "Volume", "KD"),
and Google Search Console ("Query", "Impressions", "Clicks").

Once imported, the data-resolver's `brain` tier supplies volume/KD for a page
automatically, so the agent stops asking you for it.

    from tools.keyword_import import import_keywords_csv
    n = import_keywords_csv(brain, "stitchmagic.in", csv_text=open("export.csv").read())
"""
from __future__ import annotations

import csv
import io
import re

# header aliases (lowercased) → canonical field
_TERM = {"keyword", "keywords", "phrase", "query", "search term", "term"}
_VOL = {"search volume", "volume", "avg. monthly searches", "nq", "impressions", "searches"}
_KD = {"keyword difficulty", "keyword difficulty index", "kd", "difficulty", "competition"}
_CPC = {"cpc", "cpc (usd)", "cpc usd"}
_INTENT = {"intent", "search intent", "intent type"}
_URL = {"url", "target url", "landing page", "page"}
_QWORDS = ("what", "how", "why", "when", "where", "who", "which", "is", "are",
           "can", "does", "do", "should", "will", "vs")


def _num(x):
    if x is None:
        return None
    s = re.sub(r"[^\d.\-]", "", str(x))
    if s in ("", "-", "."):
        return None
    try:
        return float(s)
    except ValueError:
        return None


def _sniff_reader(text: str):
    text = text.lstrip("﻿")
    sample = text[:4096]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
    except csv.Error:
        class _D(csv.Dialect):
            delimiter = ";" if sample.count(";") > sample.count(",") else ","
            quotechar = '"'; doublequote = True; skipinitialspace = True
            lineterminator = "\n"; quoting = csv.QUOTE_MINIMAL
        dialect = _D
    return csv.DictReader(io.StringIO(text), dialect=dialect)


def _map_headers(fieldnames):
    m = {}
    for h in fieldnames or []:
        hl = (h or "").strip().lower()
        if hl in _TERM and "term" not in m:
            m["term"] = h
        elif hl in _VOL and "volume" not in m:
            m["volume"] = h
        elif hl in _KD and "kd" not in m:
            m["kd"] = h
        elif hl in _CPC and "cpc" not in m:
            m["cpc"] = h
        elif hl in _INTENT and "intent" not in m:
            m["intent"] = h
        elif hl in _URL and "url" not in m:
            m["url"] = h
    return m


def _guess_intent(term: str, given: str = "") -> str:
    g = (given or "").strip().lower()
    if g in ("commercial", "transactional", "informational", "navigational"):
        return g
    first = term.strip().lower().split()[:1]
    if first and first[0] in _QWORDS:
        return "informational"
    if re.search(r"\b(buy|price|pricing|tool|software|platform|vendor|best|top|compare|vs|alternative)\b", term, re.I):
        return "commercial"
    return ""


def import_keywords_csv(brain, domain: str, csv_text: str | None = None,
                        path: str | None = None, source: str = "semrush_csv",
                        max_rows: int = 5000) -> dict:
    """Load keyword rows into brain.keywords. Returns a summary dict."""
    if csv_text is None:
        if not path:
            raise ValueError("provide csv_text or path")
        csv_text = open(path, "r", encoding="utf-8", errors="ignore").read()
    reader = _sniff_reader(csv_text)
    cols = _map_headers(reader.fieldnames)
    if "term" not in cols:
        return {"imported": 0, "error": "no Keyword/Query column found",
                "headers": reader.fieldnames}
    imported = questions = 0
    for i, row in enumerate(reader):
        if i >= max_rows:
            break
        term = (row.get(cols["term"]) or "").strip()
        if not term:
            continue
        volume = _num(row.get(cols["volume"])) if "volume" in cols else None
        kd = _num(row.get(cols["kd"])) if "kd" in cols else None
        url = (row.get(cols["url"]) or "").strip() if "url" in cols else ""
        intent = _guess_intent(term, row.get(cols["intent"], "") if "intent" in cols else "")
        brain.add_keyword(domain, term, intent_type=intent,
                          volume=int(volume) if volume is not None else None,
                          kd=kd, page_url=url, source=source)
        if intent == "informational" and term.lower().split()[:1] and term.lower().split()[0] in _QWORDS:
            questions += 1
        imported += 1
    return {"imported": imported, "questions": questions,
            "columns_detected": cols, "headers": reader.fieldnames}
